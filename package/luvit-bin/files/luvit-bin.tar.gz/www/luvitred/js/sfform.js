'use strict';
plugInModule.factory('scenarios',function($http, $q, $timeout) {
	var getConfigNode = function(byName, byID, elemName, configProp) {
		if (byName.hasOwnProperty(elemName) &&
			byName[elemName].hasOwnProperty(configProp)	&&
			byID.hasOwnProperty(byName[elemName][configProp])) {
			return byID[byName[elemName][configProp]];
		} else {
			return;
		}
	};
	return {
		std_serial1: {
			defaultJSON: '\
[ \
{"type":"tab","label":"Standard Serial 1","id":"b686f3dc.49791"}, \
{"id":"fb3fbd1e.04c04","type":"scenario","name":"std_serial1","x":73.5,"y":173,"z":"b686f3dc.49791","wires":[]}, \
{"id":"fbe371e0.041c9","type":"tcp endpoint","mode":"server","maxconnections":"10","idletimeout":"60","port":"","listenport":8889,"firewall":true,"host":"","datamode":"stream","datatype":"binary","newline":"n"}, \
{"id":"3d245c08.c2dba4","type":"serial-port","serialport":"/dev/ttySP0","serialbaud":"9600","databits":"8","parity":"none","stopbits":"1","flowcontrol":"none","controllines":"dce","rfc2217":"none","newline":"n","out":"raw"}, \
{"id":"752ac625.8ad538","type":"serial in","name":"serialin","topic":"ser2tcp","serial":"3d245c08.c2dba4","x":64.000007629395,"y":36.999998092651,"z":"b686f3dc.49791","wires":[["99ca8213.66358"]]}, \
{"id":"107f3645.ef80ca","type":"tcp in","endpoint":"fbe371e0.041c9","topic":"tcp2ser","name":"tcpin","x":65,"y":98,"z":"b686f3dc.49791","wires":[["50232868.afdcd8"]]}, \
{"id":"99ca8213.66358","type":"tcp out","endpoint":"fbe371e0.041c9","queueenabled":false,"mode":"all","name":"tcpout","x":301,"y":125,"z":"b686f3dc.49791","wires":[]}, \
{"id":"50232868.afdcd8","type":"serial out","name":"serialout","serial":"3d245c08.c2dba4","x":301,"y":185,"z":"b686f3dc.49791","wires":[]} \
]',
			extractModel:function(nodesByName, allNodesByID) {
				var model = {};
				if (!nodesByName) {
					model.enabled = false;
					return;
				}
				model.enabled = true;
				var tcpep = getConfigNode(nodesByName, allNodesByID, "tcpin", "endpoint");
				if (tcpep) {
					if (tcpep.hasOwnProperty("mode")) {
						if (tcpep.mode === "server") {
							model.mode = "server";
							model.port = parseInt(tcpep.listenport);
						} else if (tcpep.mode === "client") {
							model.mode = "client";
							model.port = parseInt(tcpep.port);
							model.host = tcpep.host;
						}
					}
				}

				var serial = getConfigNode(nodesByName, allNodesByID, "serialin", "serial");
				if (serial) {
					model.serialbaud = serial.serialbaud||"9600";
					model.databits = serial.databits||"8";
					model.stopbits = serial.stopbits||"1";
					model.parity = serial.parity||"none";
					model.flowcontrol = serial.flowcontrol||"none";
				}
				return model;
			},
			storeModel:function(model, allNodesByID, defaultsByName) {
				var tcpep = getConfigNode(defaultsByName, allNodesByID, "tcpin", "endpoint");
				if (tcpep) {
					if (model.mode === "client") {
						tcpep.port = model.port;
						tcpep.host = model.host;
						tcpep.mode = "client";
					} else {
						tcpep.listenport = model.port;
						tcpep.mode = "server";
					}
				}
				var serial = getConfigNode(defaultsByName, allNodesByID, "serialin", "serial");
				if (serial) {
					serial.serialbaud = model.serialbaud;
					serial.databits = model.databits;
					serial.stopbits = model.stopbits;
					serial.parity = model.parity;
					serial.flowcontrol = model.flowcontrol;
				}
			},
		},
		std_gps1: {
			defaultJSON: ' \
[ \
{"type":"tab","label":"Standard GPS 1","id":"7abed921.c0941a"}, \
{"id":"fb2fbd1e.04c05","type":"scenario","name":"std_gps1","x":61,"y":193,"z":"7abed921.c0941a","wires":[]}, \
{"id":"e1007f3e.1eff8","type":"barrier group","start":"1","name":"gpsbarrier"}, \
{"id":"cdc0bef.f323f4","type":"queueing config","ramqueuesize":"2000","flashqueuesize":"0"}, \
{"id":"6198c87b.9e6738","type":"tcp endpoint","mode":"server","maxconnections":"10","idletimeout":"60","port":"8888","listenport":8888,"firewall":true,"host":"","datamode":"stream","datatype":"binary","newline":"\\n"}, \
{"id":"f1b2045.f0e4df8","type":"GPS","name":"gps","topic":"gps","reporttype":"reports","reportrate":5,"nofixsecs":10,"fixsecs":10,"reportdist":1,"movesecs":10,"movedist":5,"turndegs":15,"turnspeed":30,"speedlimit":"","speedlimittime":"","x":55,"y":34,"z":"7abed921.c0941a","wires":[["46756f43.b98a9"]]}, \
{"id":"46756f43.b98a9","type":"combine","condition":"gps","clear":"gps","topic":"","name":"","x":244,"y":34,"z":"7abed921.c0941a","wires":[["5e50fa8a.a1af04"]]}, \
{"id":"298b64af.d6749c","type":"sysinfo","topic":"sysinfo","name":"sysinfo","x":57,"y":122,"z":"7abed921.c0941a","wires":[["46756f43.b98a9"]]}, \
{"id":"5e50fa8a.a1af04","type":"template","name":"template","field":"payload","template":"GP,{{sysinfo.serial}},{{gps.timestamp%N06}},{{gps.date%N06}},{{gps.lat%N.5}},{{gps.lon%N.5}},{{gps.altitude%N.1}}({{gps.altitudeFeet%N.1}}),{{gps.speed}}({{gps.speedMPH}}),{{gps.track}}({{gps.trackMag}}),{{gps.sats.inUse}}\\r\\n","x":244,"y":141,"z":"7abed921.c0941a","wires":[["5973a715.a68c58"]]}, \
{"id":"8b1019c1.74efe8","type":"tcp out","endpoint":"6198c87b.9e6738","queueenabled":true,"queue":"cdc0bef.f323f4","mode":"all","name":"tcpout","x":391,"y":327,"z":"7abed921.c0941a","wires":[]}, \
{"id":"5973a715.a68c58","type":"barrier","barriergroup":"e1007f3e.1eff8","outputs":"2","outputoffset":"1","name":"barrier","x":242,"y":240,"z":"7abed921.c0941a","wires":[["8b1019c1.74efe8"],["59f06eae.a60f9"]]}, \
{"id":"59f06eae.a60f9","type":"udp out","name":"udpout","addr":"192.168.5.30","iface":"","port":8893,"base64":false,"multicast":"false","x":352,"y":386,"z":"7abed921.c0941a","wires":[]} \
]',
			extractModel:function(nodesByName, allNodesByID) {
				var model = {};
				if (!nodesByName) {
					model.enabled = false;
					return;
				}
				model.enabled = true;
				var bg = getConfigNode(nodesByName, allNodesByID, "barrier", "barriergroup");
				if (bg) {
					if (bg.hasOwnProperty("start") && bg.start == "2") {
						model.outmode = "udp";
						// backend will return control. default to server so that its correct if user changes to tcp
						model.tcpmode = "server";
						if (nodesByName.hasOwnProperty("udpout")) {
							var udpout = nodesByName.udpout;
							model.host = udpout.addr||"";
							model.port = parseInt(udpout.port)||"";
						}
					} else {
						model.outmode = "tcp";
						var tcpep = getConfigNode(nodesByName, allNodesByID, "tcpout", "endpoint");
						if (tcpep) {
							if (tcpep.hasOwnProperty('mode') && tcpep.mode == "client") {
								model.tcpmode = "client";
								model.host = tcpep.host||"";
								model.port = parseInt(tcpep.port)||"";
							} else {
								model.tcpmode = "server";
								model.port = parseInt(tcpep.listenport)||"";
							}
						}
					}
				}
				if (nodesByName.hasOwnProperty("gps")) {
					var gps = nodesByName.gps;
					model.nofixsecs = parseInt(gps.nofixsecs)||0;
					model.fixsecs = parseInt(gps.fixsecs)||0;
					model.movesecs = parseInt(gps.movesecs)||0;
					model.movedist = parseInt(gps.movedist)||5;
				}
				return model;
			},
			storeModel:function(model, allNodesByID, defaultsByName) {
				var bg = getConfigNode(defaultsByName, allNodesByID, "barrier", "barriergroup");
				var tcpep = getConfigNode(defaultsByName, allNodesByID, "tcpout", "endpoint");
				var udpout = (defaultsByName.hasOwnProperty("udpout") ? allNodesByID[defaultsByName.udpout.id] : null);
				if (bg && tcpep && udpout) {
					if (model.outmode === "tcp") {
						bg.start = 1;
						if (model.tcpmode === "client") {
							tcpep.host = model.host;
							tcpep.port = model.port;
							tcpep.mode = "client";
						} else {
							tcpep.listenport = model.port;
							tcpep.mode = "server";
						}
					} else {
						bg.start = 2;
						tcpep.mode = "control";
						udpout.addr = model.host;
						udpout.port = model.port;
					}
				}
				var gps = (defaultsByName.hasOwnProperty("gps") ? allNodesByID[defaultsByName.gps.id] : null);
				if (gps) {
					gps.nofixsecs = model.nofixsecs;
					gps.fixsecs = model.fixsecs;
					gps.movesecs = model.movesecs;
					gps.movedist = model.movedist;
				}
			},
		},
	};
})
.factory('scenarioModel', function() {
	var getBy = function (nodes, byWhat) {
		var nodesByN = {};
		$.each(nodes, function(idx, node) {
			if (node && node.hasOwnProperty(byWhat)) {
				nodesByN[node[byWhat]] = node;
			}
		});
		return nodesByN;
	};

	var ensureNodes = function (nodes, defaults) {
		$.each(defaults, function(idx, defnode) { if (!nodes.hasOwnProperty(defnode.id)) { nodes[defnode.id] = defnode; } });
	};

	var removeNodes = function (nodes, defaults) {
		$.each(defaults, function(idx, defnode) { delete nodes[defnode.id]; });
	};

	var extractFormValues = function (scenarios, scenariosFound, nodesByID) {
		var model = {}
		$.each(scenarios, function(name, scenario) {
			var defaults = JSON.parse(scenario.defaultJSON);
			if (scenariosFound.hasOwnProperty(name)) {
				model[name] = scenario.extractModel(scenariosFound[name], nodesByID);
				// show
				model[name].enabled = true;
			} else {
				model[name] = scenario.extractModel(getBy(defaults, "name"), getBy(defaults, "id"));
				// hide
				model[name].enabled = false;
			}
		});
		return model;
	};

	var storeFormValues = function (model, scenarios, scenariosFound, nodesByID) {
		$.each(scenarios, function(name, scenario) {
			var defaults = JSON.parse(scenario.defaultJSON);
			if (model[name].enabled) {
				ensureNodes(nodesByID, defaults);
				scenario.storeModel(model[name], nodesByID, getBy(defaults, "name"));
			} else {
				removeNodes(nodesByID, defaults);
			}
		});
		var flows = [];
		$.each(nodesByID, function(id, node) {
			flows.push(node);
		});
		return flows;
	}

	// Extract hashes of:
	// scenario names -> node names of nodes in scenario -> nodes
	// node id -> node
	function processFlows(flows, scenariosFound, nodesByID) {
		var tabs = {};
		$.each(flows, function(idx, node) {
			if (node && node.hasOwnProperty("type") && node.hasOwnProperty("id")) {
				nodesByID[node.id] = node;
				switch (node.type) {
					case "tab":
						if (!tabs.hasOwnProperty(node.id)) {
							tabs[node.id] = {};
						}
						break;
					case "scenario":
						if (!scenariosFound.hasOwnProperty(node.name)) {
							scenariosFound[node.name] = node.z;
						}
						break;
					default:
						if (node.hasOwnProperty("z")) {
							if (node.hasOwnProperty("name")) {
								if (!tabs.hasOwnProperty(node.z)) {
									tabs[node.z] = {};
								}
								tabs[node.z][node.name] = node;
							}
						}
						break;
				}
			}
		});
		$.each(scenariosFound, function(name, tabid) {
			scenariosFound[name] = tabs[tabid];
		});
	}
	return function(scenarios, flows) {
		this.scenarios = scenarios;
		this.flows = flows;
		this.scenariosFound= {};
		this.nodesByID = {};
		processFlows(flows, this.scenariosFound, this.nodesByID);

		this.extractFormValues = function() {
			return extractFormValues(this.scenarios, this.scenariosFound, this.nodesByID);
		};
		this.storeFormValues = function(model) {
			return storeFormValues(model, this.scenarios, this.scenariosFound, this.nodesByID);
		};
	};
})
.factory('luvitRedApi',function($http, $q, $timeout, $location) {
	var flowsApiPath = '/api/libcg/flows';
	var editorEnabledPath = '/api/libcg/editorEnabled';
	var enableEditorPath = '/api/libcg/enableEditor';
	var post = function(path, request) {
		return $http.post(path, request).then(function(data) {
				if (data.hasOwnProperty('error'))
					return $q.reject(data.error);
				else
					return (data.data);
			},
			function(errorMessage){
				return $q.reject(errorMessage);
			});
	};
	var get = function(path) {
		return $http.get(path).then(function(data) {
				if (data.hasOwnProperty('error'))
					return $q.reject(data.error);
				else
					return (data.data);
			},
			function(errorMessage){
				return $q.reject(errorMessage);
			});
	};
	return {
		loadFlows: function() {
			return get(flowsApiPath);
		},
		saveFlows: function(flows) {
			return post(flowsApiPath, flows);
		},
		getEditorEnabled: function(session) {
			return post(editorEnabledPath, {session:session});
		},
		enableEditor: function(password, session) {
			return post(enableEditorPath, {password:password, session:session});
		},
	};
})
.directive('optInvalidWhen', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elem, attr, ctrl) {
			if (attr.hasOwnProperty("optInvalidWhen")) {
				scope.$watch(attr.optInvalidWhen, function (newValue, oldValue) {
					ctrl.$setValidity('invalidwhen', !newValue);
				});
				ctrl.$parsers.unshift(function(value) {
					ctrl.$setValidity('invalidwhen', !scope.$eval(attr.optInvalidWhen));
					return value;
				});
				ctrl.$formatters.unshift(function(value) {
					ctrl.$setValidity('invalidwhen', !scope.$eval(attr.optInvalidWhen));
					return value;
				});
			}
        }
    };
})
.directive('optIpOrHost', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elem, attr, ctrl) {
            var regex = new RegExp(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$|^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$/);
            ctrl.$parsers.unshift(function(value) {
                var valid = regex.test(value);
                ctrl.$setValidity('ipOrHost', valid);
                return valid ? value : undefined;
            });
            ctrl.$formatters.unshift(function(value) {
                ctrl.$setValidity('ipOrHost', regex.test(value));
                return value;
            });
        }
    };
})
.directive('optOnlyNum', function() {
	return function(scope, element, attrs) {
		var keyCode = [8,9,37,39,46,48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105,110];
		element.bind("keydown", function(event) {
			if($.inArray(event.which,keyCode) == -1) {
				scope.$apply(function(){
					scope.$eval(attrs.optOnlyNum);
					event.preventDefault();
				});
				event.preventDefault();
			}
		});
	};
})
.directive('optYesNo', function() {
	return {
		restrict: 'E',
		scope: {
			value: '='
		},
		template:
				'<div class="btn-group">' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': value, \'btn-success\': value }" ng-click="setValue(true)">yes</button>' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': !value, \'btn-danger\':  !value}" ng-click="setValue(false)">no</button>' +
				'</div>',
		require: "?^form",
		link: function(scope, element, attrs, formctrlr) {
			scope.setValue = function(value) {
				if (formctrlr !== undefined)
					formctrlr.$setDirty();
				scope.value = value;
			};
		}
	};
})
.directive('optTwoValues', function() {
	return {
		restrict: 'E',
		scope: {
			value: '=',
			label1: '@',
			label2: '@',
			value1: '@',
			value2: '@',
		},
		template:
				'<div class="btn-group">' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': value == value1, \'btn-success\': value == value1}" ng-click="setValue(value1)">{{label1}}</button>' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': value == value2, \'btn-success\': value == value2}" ng-click="setValue(value2)">{{label2}}</button>' +
				'</div>',
		require: "?^form",
		link: function(scope, element, attrs, formctrlr) {
			scope.setValue = function(value) {
				if (formctrlr !== undefined)
					formctrlr.$setDirty();
				scope.value = value;
			};
		}
	};
})
.factory('optInformer', function(){
	var errorWatchers = [];

	return {
		allInfos: [],
		addErrorWatcher: function(fn) {
			errorWatchers.push(fn);
		},
		inform: function(type, msg) {
			this.allInfos.push({
				message: msg,
				type: 'alert-' + type
				});
			angular.forEach(errorWatchers, function(fn){
				fn();
			});
		},
		remove: function(index) {
			this.allInfos.splice(index, 1);
		},

		removeAll: function() {
			this.allInfos.length = 0;
		}
	};
})
.directive("optAlert", function(optInformer, $location, $anchorScroll, $timeout) {
	return {
		restrict: 'E',
		scope: true,
		template: 	'<div ng-repeat="inform in informs">' +
					'<div ng-class="inform.type" class="alert alert-dismissable fade in informer">' +
					'<button type="button" ng-click="click($index)" class="close">&times;</button>' +
					'<div class="valignCenterWrapper">' +
					'<div class="valignCenter">' +
					'<h4><b>{{inform.message}}</b></h4>' +
					'</div></div></div></div></div>',
		controller: function($scope) {
			$scope.lastTimeout = {};
			optInformer.addErrorWatcher(function() {
				$location.hash("top");
				$anchorScroll();
				if ($scope.lastTimeout != {}) $timeout.cancel($scope.lastTimeout);
				$scope.lastTimeout = $timeout(function(){
					$scope.lastTimeout = {};
					optInformer.removeAll();
				}, 30000);
			});
			$scope.informs = optInformer.allInfos;
			$scope.click = function(index) {
				optInformer.remove(index);
			};
		}
	}
})
.directive('optPristine', function() {
	return {
		restrict: 'A',
		scope: false,
		require: 'form',
		link: function(scope, element, attrs, cntrlr) {
			if (!cntrlr.hasOwnProperty('$setPristine')) {
				cntrlr.$setPristine = function () {
					var form = scope[cntrlr.$name];
					form.$dirty = false;
					form.$pristine = true;
					for(var field in form) {
						if(form[field].$pristine === false) {
							form[field].$pristine = true;
						}
						if(form[field].$dirty === true) {
							form[field].$dirty = false;
						}
					}
				};
			}
		}
	};
})
.controller('sfCntrlr', function($scope, $q, $location, $window, scenarios, scenarioModel, optInformer, luvitRedApi) {
	$scope.model = {};
	$scope.password = "";
	init();

	function getSession() {
		var session = document.cookie.match(new RegExp('session=([^;]+)'));
		return (session?session[1]:"");
	};

	function init() {
		luvitRedApi.getEditorEnabled(getSession()).then(function(data)
		{
			$scope.editorEnabled = data.enabled;
		});
		luvitRedApi.loadFlows().then(function(data)
		{
			var modelControler = new scenarioModel(scenarios, data);
			$scope.model = modelControler.extractFormValues();
		});
	};

    $scope.baudRates = [
		"300",
		"1200",
		"2400",
		"4800",
		"9600",
		"19200",
		"57600",
		"115200"
    ];

	$scope.saving = false;
	$scope.editorLoading = false;

	$scope.onEditorLoad = function() {
		$scope.editorLoading = true;
		luvitRedApi.getEditorEnabled(getSession()).then(function(data)
		{
			$scope.editorEnabled = data.enabled;
			$scope.httpsport = data.httpsport;
			$scope.httpport = data.httpport;
			if ($location.protocol() == 'https' && $scope.httpsport) {
				$scope.editorUrl = "https://" + $location.host() + ":" + $scope.httpsport;
			} else if ($scope.httpport) {
				$scope.editorUrl = "http://" + $location.host() + ":" + $scope.httpport;
			} else {
				$scope.editorUrl = $location.protocol() + "//" + $location.host() + "/";
			}

			if (!$scope.editorEnabled) {
				$scope.password = "";
				$('#passwordModal').modal('show');
			} else {
				$window.open($scope.editorUrl);
				$scope.editorLoading = false;
			}
		},
		function(err) {
			optInformer.inform("error", "Error loading advanced editor");
			console.log("Error: ", err);
			$scope.editorLoading = false;
		});
	}

	$scope.onPwEditorLoad = function() {
		$('#passwordModal').modal('hide');

		luvitRedApi.enableEditor($scope.password, getSession()).then(
			function(data) {
				if (data&&data.enabled) {
					$window.open($scope.editorUrl);
				} else {
					optInformer.inform("error", "Not authorized");
				}
				$scope.editorLoading = false;
			},
			function(err) {
				optInformer.inform("error", "Error loading advanced editor");
				console.log("Error: ", err);
				$scope.editorLoading = false;
			}
		);
	}

	$scope.onFormReset = function() {
		$scope.sfform.$setPristine();
		init();
	};

	$scope.onFormSubmit = function() {
		$scope.saving = true;
		optInformer.removeAll();
		luvitRedApi.loadFlows().then(function(data) {
			var modelControler = new scenarioModel(scenarios, data);
			var flows = modelControler.storeFormValues($scope.model);
			return luvitRedApi.saveFlows(flows).then(function() {
				optInformer.inform("info", "Changes saved.");
				$scope.sfform.$setPristine();
				$scope.saving = false;
			});
		}).then(null, function(errorText) {
			optInformer.inform("error", errorText);
			console.log("Error: " + errorText);
			$scope.sfform.$setDirty();
			$scope.saving = false;
			return;
		});
	};
});
