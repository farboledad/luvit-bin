'use strict';
plugInModule.factory('scenarios',function($http, $q, $timeout) {
	var getConfigNode = function(byName, byID, elemName, configProp) {
		if (byName.hasOwnProperty(elemName) &&
			byName[elemName].hasOwnProperty(configProp)	&&
			byID.hasOwnProperty(byName[elemName][configProp])) {
			return byID[byName[elemName][configProp]];
		}
	};
	return {
		std_serial1: {
			defaultJSON: '\
[{"id":"f182554e.4525c","type":"tab","order":0,"label":"Standard Serial 1"}, \
{"id":"fbe371e0.041c9","type":"tcp endpoint","__package":"luvitred/core-io","__version":"0.1.0","name":"","mode":"server","maxconnections":"10","reconnectTime":"","idletimeout":"60","port":"","listenport":8889,"host":"","datamode":"stream","datatype":"binary","delimiter":"","conntimeout":"","nagle":false,"firewall":true,"keepalive":"","internetevents":false,"tlsclientconfig":"_ADD_","tlsserverconfig":"_ADD_","protolog":false,"__users":["4931aff1.9e16","d81f07e6.d81ba8"]}, \
{"id":"3d245c08.c2dba4","type":"serial-port","__package":"luvitred/core-io","__version":"0.1.0","serialport":"/dev/ttySP0","serialbaud":"9600","databits":"8","parity":"none","stopbits":"1","switchmode":"no","flowcontrol":"none","controllines":"dce","newline":"n","out":"raw","disabled":false,"__users":["278b7773.762688","86c60b49.545138"]}, \
{"id":"c09a3dbe.84f14","type":"scenario","__package":"luvitred/core-core","__version":"0.1.0","name":"std_serial1","x":112.5,"y":125,"z":"f182554e.4525c","wires":[]}, \
{"id":"278b7773.762688","type":"serial in","__package":"luvitred/core-io","__version":"0.1.0","name":"serialin","topic":"ser2tcp","serial":"3d245c08.c2dba4","x":100,"y":25,"z":"f182554e.4525c","wires":[["d81f07e6.d81ba8"]]}, \
{"id":"4931aff1.9e16","type":"tcp in","__package":"luvitred/core-io","__version":"0.1.0","endpoint":"fbe371e0.041c9","topic":"tcp2ser","name":"tcpin","x":100,"y":75,"z":"f182554e.4525c","wires":[["86c60b49.545138"]]}, \
{"id":"d81f07e6.d81ba8","type":"tcp out","__package":"luvitred/core-io","__version":"0.1.0","endpoint":"fbe371e0.041c9","queueenabled":false,"queue":"_ADD_","mode":"all","name":"tcpout","x":250,"y":25,"z":"f182554e.4525c","wires":[]}, \
{"id":"86c60b49.545138","type":"serial out","__package":"luvitred/core-io","__version":"0.1.0","name":"serialout","linepace":"","serial":"3d245c08.c2dba4","x":262.5,"y":75,"z":"f182554e.4525c","wires":[]}]',

			extractModel:function(nodesByName, allNodesByID) {
				var model = {};
				if (!nodesByName) {
					model.enabled = false;
					return;
				}
				model.enabled = true;
				var tcpep = getConfigNode(nodesByName, allNodesByID, "tcpin", "endpoint");
				if (tcpep) {
					if (tcpep.hasOwnProperty("mode")) {
						if (tcpep.mode === "server") {
							model.mode = "server";
							model.port = parseInt(tcpep.listenport);
						} else if (tcpep.mode === "client") {
							model.mode = "client";
							model.port = parseInt(tcpep.port);
							model.host = tcpep.host;
						}
					}
				}

				var serial = getConfigNode(nodesByName, allNodesByID, "serialin", "serial");
				if (serial) {
					model.serialbaud = serial.serialbaud||"9600";
					model.databits = serial.databits||"8";
					model.stopbits = serial.stopbits||"1";
					model.parity = serial.parity||"none";
					model.flowcontrol = serial.flowcontrol||"none";
				}
				return model;
			},
			storeModel:function(model, allNodesByID, defaultsByName) {
				var tcpep = getConfigNode(defaultsByName, allNodesByID, "tcpin", "endpoint");
				if (tcpep) {
					if (model.mode === "client") {
						tcpep.port = model.port;
						tcpep.host = model.host;
						tcpep.mode = "client";
					} else {
						tcpep.listenport = model.port;
						tcpep.mode = "server";
					}
				}
				var serial = getConfigNode(defaultsByName, allNodesByID, "serialin", "serial");
				if (serial) {
					serial.serialbaud = model.serialbaud;
					serial.databits = model.databits;
					serial.stopbits = model.stopbits;
					serial.parity = model.parity;
					serial.flowcontrol = model.flowcontrol;
				}
			},
		},
		std_gps1: {
			defaultJSON: ' \
[{"id":"b78bdbfc.0400a","type":"tab","order":0,"label":"Standard GPS 1"}, \
{"id":"e1007f3e.1eff8","type":"barrier group","__package":"luvitred/core-logic","__version":"0.1.0","start":"1","name":"gpsbarrier","__users":["c460f85a.300e3"]}, \
{"id":"cdc0bef.f323f4","type":"queueing config","__package":"luvitred/core-io","__version":"0.1.0","ramqueuesize":"2000","flashqueuesize":"0","__users":["556d6e05.f9b38"]}, \
{"id":"6198c87b.9e6738","type":"tcp endpoint","__package":"luvitred/core-io","__version":"0.1.0","name":"","mode":"server","maxconnections":"10","reconnectTime":"","idletimeout":"60","port":"8888","listenport":8888,"host":"","datamode":"stream","datatype":"binary","delimiter":"","conntimeout":"","nagle":false,"firewall":true,"keepalive":"","internetevents":false,"tlsclientconfig":"_ADD_","tlsserverconfig":"_ADD_","protolog":false,"__users":["556d6e05.f9b38"]}, \
{"id":"cbd47c9.c335f","type":"scenario","__package":"luvitred/core-core","__version":"0.1.0","name":"std_gps1","x":112.5,"y":200,"z":"b78bdbfc.0400a","wires":[]}, \
{"id":"52963c8f.e04bd4","type":"GPS","__package":"luvitred/cloudgate-io","__version":"0.1.0","name":"gps","topic":"gps","reporttype":"reports","reportrate":5,"nofixsecs":10,"fixsecs":10,"reportdist":1,"movesecs":10,"movedist":5,"turnaccel":"","turndegs":15,"turnspeed":30,"speedlimit":"","speedlimittime":"","x":125,"y":100,"z":"b78bdbfc.0400a","wires":[["abe45413.b8c658"]]}, \
{"id":"abe45413.b8c658","type":"combine","__package":"luvitred/core-logic","__version":"0.1.0","condition":"gps","clear":"gps","topic":"","collapse":false,"name":"","x":287.5,"y":100,"z":"b78bdbfc.0400a","wires":[["d687ccd1.7659d8"]]}, \
{"id":"8f3a6c68.1342d8","type":"sysinfo","__package":"luvitred/cloudgate-sys","__version":"0.1.0","topic":"sysinfo","dontfire":false,"name":"sysinfo","x":112.5,"y":150,"z":"b78bdbfc.0400a","wires":[["abe45413.b8c658"]]}, \
{"id":"d687ccd1.7659d8","type":"template","__package":"luvitred/core-core","__version":"0.1.0","name":"template","field":"payload","template":"GP,{{sysinfo.serial}},{{gps.timestamp%N06}},{{gps.date%N06}},{{gps.lat%N.5}},{{gps.lon%N.5}},{{gps.altitude%N.1}}({{gps.altitudeFeet%N.1}}),{{gps.speed}}({{gps.speedMPH}}),{{gps.track}}({{gps.trackMag}}),{{gps.sats.inUse}}\\r\\n","x":462.5,"y":100,"z":"b78bdbfc.0400a","wires":[["c460f85a.300e3"]]}, \
{"id":"556d6e05.f9b38","type":"tcp out","__package":"luvitred/core-io","__version":"0.1.0","endpoint":"6198c87b.9e6738","queueenabled":true,"queue":"cdc0bef.f323f4","mode":"all","name":"tcpout","x":875,"y":75,"z":"b78bdbfc.0400a","wires":[]}, \
{"id":"c460f85a.300e3","type":"barrier","__package":"luvitred/core-logic","__version":"0.1.0","barriergroup":"e1007f3e.1eff8","outputs":"2","outputoffset":"1","codeswitch":false,"prefixcode":"","portone":"","portall":"","name":"barrier","x":662.5,"y":100,"z":"b78bdbfc.0400a","wires":[["556d6e05.f9b38"],["74ac6127.58b678"]]}, \
{"id":"74ac6127.58b678","type":"udp out","__package":"luvitred/core-io","__version":"0.1.0","name":"udpout","addr":"192.168.5.30","iface":"","port":8893,"outport":"0","base64":false,"multicast":"false","x":887.5,"y":125,"z":"b78bdbfc.0400a","wires":[]}]',

			extractModel:function(nodesByName, allNodesByID) {
				var model = {};
				if (!nodesByName) {
					model.enabled = false;
					return;
				}
				model.enabled = true;
				var bg = getConfigNode(nodesByName, allNodesByID, "barrier", "barriergroup");
				if (bg) {
					if (bg.hasOwnProperty("start") && bg.start == "2") {
						model.outmode = "udp";
						// backend will return control. default to server so that its correct if user changes to tcp
						model.tcpmode = "server";
						if (nodesByName.hasOwnProperty("udpout")) {
							var udpout = nodesByName.udpout;
							model.host = udpout.addr||"";
							model.port = parseInt(udpout.port)||"";
						}
					} else {
						model.outmode = "tcp";
						var tcpep = getConfigNode(nodesByName, allNodesByID, "tcpout", "endpoint");
						if (tcpep) {
							if (tcpep.hasOwnProperty('mode') && tcpep.mode == "client") {
								model.tcpmode = "client";
								model.host = tcpep.host||"";
								model.port = parseInt(tcpep.port)||"";
							} else {
								model.tcpmode = "server";
								model.port = parseInt(tcpep.listenport)||"";
							}
						}
					}
				}
				if (nodesByName.hasOwnProperty("gps")) {
					var gps = nodesByName.gps;
					model.nofixsecs = parseInt(gps.nofixsecs)||0;
					model.fixsecs = parseInt(gps.fixsecs)||0;
					model.movesecs = parseInt(gps.movesecs)||0;
					model.movedist = parseInt(gps.movedist)||5;
				}
				return model;
			},
			storeModel:function(model, allNodesByID, defaultsByName) {
				var bg = getConfigNode(defaultsByName, allNodesByID, "barrier", "barriergroup");
				var tcpep = getConfigNode(defaultsByName, allNodesByID, "tcpout", "endpoint");
				var udpout = (defaultsByName.hasOwnProperty("udpout") ? allNodesByID[defaultsByName.udpout.id] : null);
				if (bg && tcpep && udpout) {
					if (model.outmode === "tcp") {
						bg.start = 1;
						if (model.tcpmode === "client") {
							tcpep.host = model.host;
							tcpep.port = model.port;
							tcpep.mode = "client";
						} else {
							tcpep.listenport = model.port;
							tcpep.mode = "server";
						}
					} else {
						bg.start = 2;
						tcpep.mode = "control";
						udpout.addr = model.host;
						udpout.port = model.port;
					}
				}
				var gps = (defaultsByName.hasOwnProperty("gps") ? allNodesByID[defaultsByName.gps.id] : null);
				if (gps) {
					gps.nofixsecs = model.nofixsecs;
					gps.fixsecs = model.fixsecs;
					gps.movesecs = model.movesecs;
					gps.movedist = model.movedist;
				}
			},
		},
	};
})
.factory('scenarioModel', function() {
	var getBy = function (nodes, byWhat) {
		var nodesByN = {};
		$.each(nodes, function(idx, node) {
			if (node && node.hasOwnProperty(byWhat)) {
				nodesByN[node[byWhat]] = node;
			}
		});
		return nodesByN;
	};

	var ensureNodes = function (nodes, defaults) {
		$.each(defaults, function(idx, defnode) { if (!nodes.hasOwnProperty(defnode.id)) { nodes[defnode.id] = defnode; } });
	};

	var removeNodes = function (nodes, defaults) {
		$.each(defaults, function(idx, defnode) { delete nodes[defnode.id]; });
	};

	var extractFormValues = function (scenarios, scenariosFound, nodesByID) {
		var model = {}
		$.each(scenarios, function(name, scenario) {
			var defaults = JSON.parse(scenario.defaultJSON);
			if (scenariosFound.hasOwnProperty(name)) {
				model[name] = scenario.extractModel(scenariosFound[name], nodesByID);
				// show
				model[name].enabled = true;
			} else {
				model[name] = scenario.extractModel(getBy(defaults, "name"), getBy(defaults, "id"));
				// hide
				model[name].enabled = false;
			}
		});
		return model;
	};

	var storeFormValues = function (model, scenarios, scenariosFound, nodesByID) {
		$.each(scenarios, function(name, scenario) {
			var defaults = JSON.parse(scenario.defaultJSON);
			if (model[name].enabled) {
				ensureNodes(nodesByID, defaults);
				scenario.storeModel(model[name], nodesByID, getBy(defaults, "name"));
			} else {
				removeNodes(nodesByID, defaults);
			}
		});
		var flows = [];
		$.each(nodesByID, function(id, node) {
			flows.push(node);
		});
		return flows;
	}

	// Extract hashes of:
	// scenario names -> node names of nodes in scenario -> nodes
	// node id -> node
	function processFlows(flows, scenariosFound, nodesByID) {
		var tabs = {};
		$.each(flows, function(idx, node) {
			if (node && node.hasOwnProperty("type") && node.hasOwnProperty("id")) {
				nodesByID[node.id] = node;
				switch (node.type) {
					case "tab":
						if (!tabs.hasOwnProperty(node.id)) {
							tabs[node.id] = {};
						}
						break;
					case "scenario":
						if (!scenariosFound.hasOwnProperty(node.name)) {
							scenariosFound[node.name] = node.z;
						}
						break;
					default:
						if (node.hasOwnProperty("z")) {
							if (node.hasOwnProperty("name")) {
								if (!tabs.hasOwnProperty(node.z)) {
									tabs[node.z] = {};
								}
								tabs[node.z][node.name] = node;
							}
						}
						break;
				}
			}
		});
		$.each(scenariosFound, function(name, tabid) {
			scenariosFound[name] = tabs[tabid];
		});
	}
	return function(scenarios, flows) {
		this.scenarios = scenarios;
		this.flows = flows;
		this.scenariosFound= {};
		this.nodesByID = {};
		processFlows(flows, this.scenariosFound, this.nodesByID);

		this.extractFormValues = function() {
			return extractFormValues(this.scenarios, this.scenariosFound, this.nodesByID);
		};
		this.storeFormValues = function(model) {
			return storeFormValues(model, this.scenarios, this.scenariosFound, this.nodesByID);
		};
	};
})
.factory('luvitRedApi',function($http, $q, $timeout, $location) {
	var flowsApiPath = '/api/libcg/flows';
	var editorEnabledPath = '/api/libcg/editorEnabled';
	var enableEditorPath = '/api/libcg/enableEditor';
	var post = function(path, request) {
		return $http.post(path, request).then(function(data) {
				if (data.hasOwnProperty('error'))
					return $q.reject(data.error);
				else
					return (data.data);
			},
			function(errorMessage){
				return $q.reject(errorMessage);
			});
	};
	var get = function(path) {
		return $http.get(path).then(function(data) {
				if (data.hasOwnProperty('error'))
					return $q.reject(data.error);
				else
					return (data.data);
			},
			function(errorMessage){
				return $q.reject(errorMessage);
			});
	};
	return {
		loadFlows: function() {
			return get(flowsApiPath);
		},
		saveFlows: function(flows) {
			return post(flowsApiPath, flows);
		},
		getEditorEnabled: function(session) {
			return post(editorEnabledPath, {session:session});
		},
		enableEditor: function(password, session) {
			return post(enableEditorPath, {password:password, session:session});
		},
	};
})
.directive('optInvalidWhen', function() {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, elem, attr, ctrl) {
			if (attr.hasOwnProperty("optInvalidWhen")) {
				scope.$watch(attr.optInvalidWhen, function (newValue, oldValue) {
					ctrl.$setValidity('invalidwhen', !newValue);
				});
				ctrl.$parsers.unshift(function(value) {
					ctrl.$setValidity('invalidwhen', !scope.$eval(attr.optInvalidWhen));
					return value;
				});
				ctrl.$formatters.unshift(function(value) {
					ctrl.$setValidity('invalidwhen', !scope.$eval(attr.optInvalidWhen));
					return value;
				});
			}
		}
	};
})
.directive('optIpOrHost', function() {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, elem, attr, ctrl) {
			var regex = new RegExp(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$|^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$/);
			ctrl.$parsers.unshift(function(value) {
				var valid = regex.test(value);
				ctrl.$setValidity('ipOrHost', valid);
				return valid ? value : undefined;
			});
			ctrl.$formatters.unshift(function(value) {
				ctrl.$setValidity('ipOrHost', regex.test(value));
				return value;
			});
		}
	};
})
.directive('optOnlyNum', function() {
	return function(scope, element, attrs) {
		var keyCode = [8,9,37,39,46,48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105,110];
		element.bind("keydown", function(event) {
			if($.inArray(event.which,keyCode) == -1) {
				scope.$apply(function(){
					scope.$eval(attrs.optOnlyNum);
					event.preventDefault();
				});
				event.preventDefault();
			}
		});
	};
})
.directive('optYesNo', function() {
	return {
		restrict: 'E',
		scope: {
			value: '='
		},
		template:
				'<div class="btn-group">' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': value, \'btn-success\': value }" ng-click="setValue(true)">yes</button>' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': !value, \'btn-danger\':  !value}" ng-click="setValue(false)">no</button>' +
				'</div>',
		require: "?^form",
		link: function(scope, element, attrs, formctrlr) {
			scope.setValue = function(value) {
				if (formctrlr !== undefined)
					formctrlr.$setDirty();
				scope.value = value;
			};
		}
	};
})
.directive('optTwoValues', function() {
	return {
		restrict: 'E',
		scope: {
			value: '=',
			label1: '@',
			label2: '@',
			value1: '@',
			value2: '@',
		},
		template:
				'<div class="btn-group">' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': value == value1, \'btn-success\': value == value1}" ng-click="setValue(value1)">{{label1}}</button>' +
				'<button class="btn btn-default" type="button" ng-class="{\'active\': value == value2, \'btn-success\': value == value2}" ng-click="setValue(value2)">{{label2}}</button>' +
				'</div>',
		require: "?^form",
		link: function(scope, element, attrs, formctrlr) {
			scope.setValue = function(value) {
				if (formctrlr !== undefined)
					formctrlr.$setDirty();
				scope.value = value;
			};
		}
	};
})
.factory('optInformer', function(){
	var errorWatchers = [];

	return {
		allInfos: [],
		addErrorWatcher: function(fn) {
			errorWatchers.push(fn);
		},
		inform: function(type, msg) {
			this.allInfos.push({
				message: msg,
				type: 'alert-' + type
				});
			angular.forEach(errorWatchers, function(fn){
				fn();
			});
		},
		remove: function(index) {
			this.allInfos.splice(index, 1);
		},

		removeAll: function() {
			this.allInfos.length = 0;
		}
	};
})
.directive("optAlert", function(optInformer, $location, $anchorScroll, $timeout) {
	return {
		restrict: 'E',
		scope: true,
		template: 	'<div ng-repeat="inform in informs">' +
					'<div ng-class="inform.type" class="alert alert-dismissable fade in informer">' +
					'<button type="button" ng-click="click($index)" class="close">&times;</button>' +
					'<div class="valignCenterWrapper">' +
					'<div class="valignCenter">' +
					'<h4><b>{{inform.message}}</b></h4>' +
					'</div></div></div></div></div>',
		controller: function($scope) {
			$scope.lastTimeout = {};
			optInformer.addErrorWatcher(function() {
				$location.hash("top");
				$anchorScroll();
				if ($scope.lastTimeout != {}) $timeout.cancel($scope.lastTimeout);
				$scope.lastTimeout = $timeout(function(){
					$scope.lastTimeout = {};
					optInformer.removeAll();
				}, 30000);
			});
			$scope.informs = optInformer.allInfos;
			$scope.click = function(index) {
				optInformer.remove(index);
			};
		}
	}
})
.directive('optPristine', function() {
	return {
		restrict: 'A',
		scope: false,
		require: 'form',
		link: function(scope, element, attrs, cntrlr) {
			if (!cntrlr.hasOwnProperty('$setPristine')) {
				cntrlr.$setPristine = function () {
					var form = scope[cntrlr.$name];
					form.$dirty = false;
					form.$pristine = true;
					for(var field in form) {
						if(form[field].$pristine === false) {
							form[field].$pristine = true;
						}
						if(form[field].$dirty === true) {
							form[field].$dirty = false;
						}
					}
				};
			}
		}
	};
})
.controller('sfCntrlr', function($scope, $q, $location, $window, scenarios, scenarioModel, optInformer, luvitRedApi) {
	$scope.model = {};
	$scope.password = "";
	init();

	function getSession() {
		var session = document.cookie.match(new RegExp('session=([^;]+)'));
		return (session?session[1]:"");
	};

	function init() {
		luvitRedApi.getEditorEnabled(getSession()).then(function(data)
		{
			$scope.editorEnabled = data.enabled;
		});
		luvitRedApi.loadFlows().then(function(data)
		{
			var modelControler = new scenarioModel(scenarios, data);
			$scope.model = modelControler.extractFormValues();
		});
	};

	$scope.baudRates = [ "300", "1200", "2400", "4800", "9600", "19200", "57600", "115200" ];

	$scope.saving = false;
	$scope.editorLoading = false;

	$scope.onEditorLoad = function() {
		$scope.editorLoading = true;
		$scope.window = $window.open('','_blank');

		luvitRedApi.getEditorEnabled(getSession()).then(function(data) {
			$scope.editorEnabled = data.enabled;
			$scope.httpsport = data.httpsport;
			$scope.httpport = data.httpport;
			if ($location.protocol() == 'https' && $scope.httpsport) {
				$scope.editorUrl = "https://" + $location.host() + ":" + $scope.httpsport;
			} else if ($scope.httpport) {
				$scope.editorUrl = "http://" + $location.host() + ":" + $scope.httpport;
			} else {
				$scope.editorUrl = $location.protocol() + "//" + $location.host() + "/";
			}
		}).then(function() {
			if ($scope.editorEnabled) {
				$scope.window.location.href = $scope.editorUrl;
				$scope.editorLoading = false;
				return;
			}
			return luvitRedApi.enableEditor($scope.password, getSession()).then(function(data) {
				if (data && data.enabled) {
					$scope.window.location.href = $scope.editorUrl;
				} else {
					optInformer.inform("error", "Not authorized");
					$scope.window.close();
				}
				$scope.password = "";
				$scope.editorLoading = false;
			});
		}).then(null, function(err) {
			optInformer.inform("error", "Error loading advanced editor");
			console.log("Error: ", err);
			$scope.editorLoading = false;
			$scope.password = "";
			$scope.window.close();
		});
	};

	$scope.onFormReset = function() {
		$scope.sfform.$setPristine();
		init();
	};

	$scope.onFormSubmit = function() {
		$scope.saving = true;
		optInformer.removeAll();
		luvitRedApi.loadFlows().then(function(data) {
			var modelControler = new scenarioModel(scenarios, data);
			var flows = modelControler.storeFormValues($scope.model);
			return luvitRedApi.saveFlows(flows).then(function() {
				optInformer.inform("info", "Changes saved.");
				$scope.sfform.$setPristine();
				$scope.saving = false;
			});
		}).then(null, function(errorText) {
			optInformer.inform("error", errorText);
			console.log("Error: " + errorText);
			$scope.sfform.$setDirty();
			$scope.saving = false;
			return;
		});
	};
});
