LJ "@bin/deps/libcurl/libs/imports.lua�C 
   A �4   6 '  B=  +  6 5 BX
�6 9  9	 B=    X�X�ER�  X�6 ' B9  9	'
 BL  �@
	struct curl_slist {
	  char *data;
	  struct curl_slist *next;
	};

	struct curl_slist_wrapper {
		struct curl_slist *head;
	};

	struct curl_slist *curl_slist_append(struct curl_slist *, const char *);
	void curl_slist_free_all(struct curl_slist *);

	enum CURLMSG {
		CURLMSG_NONE, /* first, not used */
		CURLMSG_DONE, /* This easy handle has completed. 'result' contains the CURLcode of the transfer */
		CURLMSG_LAST  /* last, not used */
	};

	struct CURLMsg {
		enum CURLMSG msg;    /* what this message means */
		void *easy_handle;   /* the handle it concerns */
		union {
			void *whatever;  /* message-specific data */
			int result;      /* return code for transfer */
		} data;
	};

	enum curl_global_option
	{
		CURL_GLOBAL_ALL = 2,
	};

	enum curl_multi_option
	{
		CURLMOPT_SOCKETFUNCTION = 20000 + 1,
		CURLMOPT_TIMERFUNCTION  = 20000 + 4
	};

	enum curl_socket_option
	{
		CURL_SOCKET_TIMEOUT = -1
	};

	enum curl_poll_option
	{
		CURL_POLL_NONE   = 0,
		CURL_POLL_IN     = 1,
		CURL_POLL_OUT    = 2,
		CURL_POLL_INOUT  = 3,
		CURL_POLL_REMOVE = 4
	};

	typedef enum {
	  CURLUSESSL_NONE,    /* do not attempt to use SSL */
	  CURLUSESSL_TRY,     /* try using SSL, proceed anyway otherwise */
	  CURLUSESSL_CONTROL, /* SSL for the control connection or fail */
	  CURLUSESSL_ALL      /* SSL for all communication or fail */
	} curl_usessl;

	enum curl_option
	{
		CURLOPT_URL                     = 10002,
		CURLOPT_USERPWD                 = 10005,
		CURLOPT_WRITEFUNCTION           = 20011,
		CURLOPT_READFUNCTION            = 20012,
		CURLOPT_INFILESIZE              =    14,
		CURLOPT_HTTPHEADER              = 10023,
		CURLOPT_VERBOSE                 =    41,
		CURLOPT_NOPROGRESS              =    43,
		CURLOPT_UPLOAD                  =    46,
		CURLOPT_DIRLISTONLY             =    48,
		CURLOPT_FOLLOWLOCATION          =    52,
		CURLOPT_TRANSFERTEXT            =    53,
		CURLOPT_PUT                     =    54,
		CURLOPT_PROGRESSFUNCTION        = 20056,
		CURLOPT_SSL_VERIFYPEER          =    64,
		CURLOPT_CAINFO                  = 10065,
		CURLOPT_FORBID_REUSE            =    75,
		CURLOPT_SSL_VERIFYHOST          =    81,
		CURLOPT_FTP_USE_EPSV            =    85,
		CURLOPT_DEBUGFUNCTION           = 20094,
		CURLOPT_FTP_CREATE_MISSING_DIRS =   110,
		CURLOPT_INFILESIZE_LARGE        = 30115,
		CURLOPT_USE_SSL                 =   119,
		CURLOPT_FTP_SSL_CCC             =   154,
	};

	enum curl_cselect_option
	{
		CURL_CSELECT_IN  = 0x01,
		CURL_CSELECT_OUT = 0x02
	};

	enum curl_read_return_codes
	{
		CURL_READFUNC_ABORT = 0x10000000,
		CURL_READFUNC_PAUSE = 0x10000001
	};

	/*
	#define CURLOPTTYPE_LONG          0
	#define CURLOPTTYPE_OBJECTPOINT   10000
	#define CURLOPTTYPE_FUNCTIONPOINT 20000
	#define CURLOPTTYPE_OFF_T         30000
	*/

	void *curl_easy_init();
	int   curl_easy_setopt(void *curl, enum curl_option option, ...);
	int   curl_easy_perform(void *curl);
	void  curl_easy_cleanup(void *curl);
	char *curl_easy_strerror(int code);
	void  curl_easy_reset(void *curl);
	int   curl_easy_pause(void *curl , int bitmask);

	int   curl_global_init(enum curl_global_option option);
	void curl_global_cleanup(void);

	void *curl_multi_init();
	int   curl_multi_setopt(void *curlm, enum curl_multi_option option, ...);
	int   curl_multi_add_handle(void *curlm, void *curl_handle);
	int   curl_multi_socket_action(void *curlm, int s, int ev_bitmask, int *running_handles);
	int   curl_multi_assign(void *curlm, int sockfd, void *sockp);
	int   curl_multi_remove_handle(void *curlm, void *curl_handle);
	struct CURLMsg *curl_multi_info_read(void *curlm, int *msgs_in_queue);
	int   curl_multi_cleanup(void *curlm);

	typedef enum {
		CURLINFO_STRING   = 0x100000,
		CURLINFO_LONG     = 0x200000,
		CURLINFO_DOUBLE   = 0x300000,
		CURLINFO_SLIST    = 0x400000,
		CURLINFO_PTR      = 0x400000, /* same as SLIST */
		CURLINFO_SOCKET   = 0x500000,
		CURLINFO_OFF_T    = 0x600000,
		CURLINFO_MASK     = 0x0fffff,
		CURLINFO_TYPEMASK = 0xf00000
	} CURLINFO_CONST;

	typedef enum {
		CURLINFO_NONE, /* first, never use this */
		CURLINFO_EFFECTIVE_URL    = CURLINFO_STRING + 1,
		CURLINFO_RESPONSE_CODE    = CURLINFO_LONG   + 2,
		CURLINFO_TOTAL_TIME       = CURLINFO_DOUBLE + 3,
		CURLINFO_NAMELOOKUP_TIME  = CURLINFO_DOUBLE + 4,
		CURLINFO_CONNECT_TIME     = CURLINFO_DOUBLE + 5,
		CURLINFO_PRETRANSFER_TIME = CURLINFO_DOUBLE + 6,
		CURLINFO_SIZE_UPLOAD      = CURLINFO_DOUBLE + 7,
		CURLINFO_SIZE_UPLOAD_T    = CURLINFO_OFF_T  + 7,
		CURLINFO_SIZE_DOWNLOAD    = CURLINFO_DOUBLE + 8,
		CURLINFO_SIZE_DOWNLOAD_T  = CURLINFO_OFF_T  + 8,
		CURLINFO_SPEED_DOWNLOAD   = CURLINFO_DOUBLE + 9,
		CURLINFO_SPEED_DOWNLOAD_T = CURLINFO_OFF_T  + 9,
		CURLINFO_SPEED_UPLOAD     = CURLINFO_DOUBLE + 10,
		CURLINFO_SPEED_UPLOAD_T   = CURLINFO_OFF_T  + 10,
		CURLINFO_HEADER_SIZE      = CURLINFO_LONG   + 11,
		CURLINFO_REQUEST_SIZE     = CURLINFO_LONG   + 12,
		CURLINFO_SSL_VERIFYRESULT = CURLINFO_LONG   + 13,
		CURLINFO_FILETIME         = CURLINFO_LONG   + 14,
		CURLINFO_CONTENT_LENGTH_DOWNLOAD   = CURLINFO_DOUBLE + 15,
		CURLINFO_CONTENT_LENGTH_DOWNLOAD_T = CURLINFO_OFF_T  + 15,
		CURLINFO_CONTENT_LENGTH_UPLOAD     = CURLINFO_DOUBLE + 16,
		CURLINFO_CONTENT_LENGTH_UPLOAD_T   = CURLINFO_OFF_T  + 16,
		CURLINFO_STARTTRANSFER_TIME = CURLINFO_DOUBLE + 17,
		CURLINFO_CONTENT_TYPE     = CURLINFO_STRING + 18,
		CURLINFO_REDIRECT_TIME    = CURLINFO_DOUBLE + 19,
		CURLINFO_REDIRECT_COUNT   = CURLINFO_LONG   + 20,
		CURLINFO_PRIVATE          = CURLINFO_STRING + 21,
		CURLINFO_HTTP_CONNECTCODE = CURLINFO_LONG   + 22,
		CURLINFO_HTTPAUTH_AVAIL   = CURLINFO_LONG   + 23,
		CURLINFO_PROXYAUTH_AVAIL  = CURLINFO_LONG   + 24,
		CURLINFO_OS_ERRNO         = CURLINFO_LONG   + 25,
		CURLINFO_NUM_CONNECTS     = CURLINFO_LONG   + 26,
		CURLINFO_SSL_ENGINES      = CURLINFO_SLIST  + 27,
		CURLINFO_COOKIELIST       = CURLINFO_SLIST  + 28,
		CURLINFO_LASTSOCKET       = CURLINFO_LONG   + 29,
		CURLINFO_FTP_ENTRY_PATH   = CURLINFO_STRING + 30,
		CURLINFO_REDIRECT_URL     = CURLINFO_STRING + 31,
		CURLINFO_PRIMARY_IP       = CURLINFO_STRING + 32,
		CURLINFO_APPCONNECT_TIME  = CURLINFO_DOUBLE + 33,
		CURLINFO_CERTINFO         = CURLINFO_PTR    + 34,
		CURLINFO_CONDITION_UNMET  = CURLINFO_LONG   + 35,
		CURLINFO_RTSP_SESSION_ID  = CURLINFO_STRING + 36,
		CURLINFO_RTSP_CLIENT_CSEQ = CURLINFO_LONG   + 37,
		CURLINFO_RTSP_SERVER_CSEQ = CURLINFO_LONG   + 38,
		CURLINFO_RTSP_CSEQ_RECV   = CURLINFO_LONG   + 39,
		CURLINFO_PRIMARY_PORT     = CURLINFO_LONG   + 40,
		CURLINFO_LOCAL_IP         = CURLINFO_STRING + 41,
		CURLINFO_LOCAL_PORT       = CURLINFO_LONG   + 42,
		CURLINFO_TLS_SESSION      = CURLINFO_PTR    + 43,
		CURLINFO_ACTIVESOCKET     = CURLINFO_SOCKET + 44,
		CURLINFO_TLS_SSL_PTR      = CURLINFO_PTR    + 45,
		CURLINFO_HTTP_VERSION     = CURLINFO_LONG   + 46,
		CURLINFO_PROXY_SSL_VERIFYRESULT = CURLINFO_LONG + 47,
		CURLINFO_PROTOCOL         = CURLINFO_LONG   + 48,
		CURLINFO_SCHEME           = CURLINFO_STRING + 49,
		/* Fill in new entries below here! */

		CURLINFO_LASTONE          = 49
	} CURLINFO;

	int curl_easy_getinfo(void *curl, CURLINFO info, ...);

	/* This is a return code for the read callback that, when returned, will
	   signal libcurl to immediately abort the current transfer.
	#define CURL_READFUNC_ABORT 0x10000000
		This is a return code for the read callback that, when returned, will
	   signal libcurl to pause sending data on the current transfer.
	#define CURL_READFUNC_PAUSE 0x10000001
	*/

	typedef enum {
	  CURLINFO_TEXT = 0,
	  CURLINFO_HEADER_IN,    /* 1 */
	  CURLINFO_HEADER_OUT,   /* 2 */
	  CURLINFO_DATA_IN,      /* 3 */
	  CURLINFO_DATA_OUT,     /* 4 */
	  CURLINFO_SSL_DATA_IN,  /* 5 */
	  CURLINFO_SSL_DATA_OUT, /* 6 */
	} curl_infotype;

	typedef int (*curl_debug_callback_ptr_t)(void *curl, curl_infotype type, char *data, size_t size, void *userptr);
	typedef int (*curl_progress_callback_ptr_t)(void *userdata, double dltotal, double dlnow, double ultotal, double ulnow);
	typedef int (*curlm_socketfunction_ptr_t)(void *curlm, int sockfd, int ev_bitmask, int *running_handles);
	typedef int (*curlm_timeoutfunction_ptr_t)(void *curlm, long timeout_ms, int *userp);
	typedef size_t (*curl_datafunction_ptr_t)(char *ptr, size_t size, size_t nmemb, void *userdata);
	cdef0libcurl not found. add path in imports.lua.
error	load
pcalllibcurl  libcurl.solibcurl.so.4libcurl.so.5/usr/local/lib/libcurl.so /usr/local/lib/libcurl.so.4ipairsrequireffi				






		���exports ok   _ 
p  
  