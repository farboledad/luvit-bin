LJ  @bin/deps/uci2/libs/bindings.lua�  ��-    X�-  L    X	�- 9 - - - - &BX�- 9 - - - - &B- 9' B.  -  L � �������libuci	load	cdef




cached ffi section1 option_uci_element section2 option_lookup std_uci_element std_lookup cg_version    � 	  w �6   ' B ' ' ' ' ' ' +  3 2  �L  nint uci_lookup_ptr(struct uci_context *ctx, struct uci_ptr *ptr, char *str, bool extended, bool hidden);
�struct uci_package
{
	struct uci_element e;
	struct uci_list sections;
	struct uci_context *ctx;
	bool has_delta;
	char *path;

	/* private: */
	struct uci_backend *backend;
	void *priv;
	int n_section;
	struct uci_list delta;
	struct uci_list saved_delta;
};

struct uci_section
{
	struct uci_element e;
	struct uci_list options;
	struct uci_package *package;
	bool anonymous;
	char *type;
};

struct uci_option
{
	struct uci_element e;
	struct uci_section *section;
	enum uci_option_type type;
	union {
		struct uci_list list;
		char *string;
	} v;
};

enum uci_command {
	UCI_CMD_ADD,
	UCI_CMD_REMOVE,
	UCI_CMD_CHANGE,
	UCI_CMD_RENAME,
	UCI_CMD_REORDER,
	UCI_CMD_LIST_ADD,
	UCI_CMD_LIST_DEL,
};

struct uci_delta
{
	struct uci_element e;
	enum uci_command cmd;
	char *section;
	char *value;
};

struct uci_ptr
{
	enum uci_type target;
	enum {
		UCI_LOOKUP_DONE =     (1 << 0),
		UCI_LOOKUP_COMPLETE = (1 << 1),
		UCI_LOOKUP_EXTENDED = (1 << 2),
	} flags;

	struct uci_package *p;
	struct uci_section *s;
	struct uci_option *o;
	struct uci_element *last;

	const char *package;
	const char *section;
	const char *option;
	const char *value;
};

struct uci_context *uci_alloc_context(void);
void uci_free_context(struct uci_context *ctx);

int uci_set_confdir(struct uci_context *ctx, const char *dir);
extern int uci_set_savedir(struct uci_context *ctx, const char *dir);

extern int uci_add_section(struct uci_context *ctx, struct uci_package *p, const char *type, struct uci_section **res);
extern int uci_save(struct uci_context *ctx, struct uci_package *p);
extern int uci_commit(struct uci_context *ctx, struct uci_package **p, bool overwrite);
extern int uci_revert(struct uci_context *ctx, struct uci_ptr *ptr);

extern int uci_set(struct uci_context *ctx, struct uci_ptr *ptr);
extern int uci_delete(struct uci_context *ctx, struct uci_ptr *ptr);
extern int uci_add_list(struct uci_context *ctx, struct uci_ptr *ptr);
extern int uci_del_list(struct uci_context *ctx, struct uci_ptr *ptr);
extern int uci_add_section(struct uci_context *ctx, struct uci_package *p, const char *type, struct uci_section **res);
extern bool uci_validate_text(const char *str);
extern int uci_rename(struct uci_context *ctx, struct uci_ptr *ptr);
kstruct uci_element
{
        struct uci_list list;
        enum uci_type type;
        char *name;
};
�struct uci_element
{
        struct uci_list list;
        enum uci_type type;
        bool multi_level;
        bool hidden;
        char *name;
};
�/* UCI data structures */
enum
{
	UCI_OK = 0,
	UCI_ERR_MEM,
	UCI_ERR_INVAL,
	UCI_ERR_NOTFOUND,
	UCI_ERR_IO,
	UCI_ERR_PARSE,
	UCI_ERR_DUPLICATE,
	UCI_ERR_UNKNOWN,
	UCI_ERR_LAST
};

struct uci_list;
struct uci_list
{
	struct uci_list *next;
	struct uci_list *prev;
};

struct uci_ptr;
struct uci_element;
struct uci_package;
struct uci_section;
struct uci_option;
struct uci_delta;
struct uci_context;
struct uci_backend;
struct uci_parse_option;
struct uci_parse_context;

enum uci_type {
	UCI_TYPE_UNSPEC = 0,
	UCI_TYPE_DELTA = 1,
	UCI_TYPE_PACKAGE = 2,
	UCI_TYPE_SECTION = 3,
	UCI_TYPE_OPTION = 4,
	UCI_TYPE_PATH = 5,
	UCI_TYPE_BACKEND = 6,
	UCI_TYPE_ITEM = 7,
	UCI_TYPE_HOOK = 8,
};

enum uci_option_type {
	UCI_TYPE_STRING = 0,
	UCI_TYPE_LIST = 1,
};

enum uci_flags {
	UCI_FLAG_STRICT =        (1 << 0), /* strict mode for the parser */
	UCI_FLAG_PERROR =        (1 << 1), /* print parser error messages */
	UCI_FLAG_EXPORT_NAME =   (1 << 2), /* when exporting, name unnamed sections */
	UCI_FLAG_SAVED_DELTA = (1 << 3), /* store the saved delta in memory as well */
};
ffirequire?KU�������ffi 
section1 	option_uci_element std_uci_element section2 option_lookup std_lookup cached   