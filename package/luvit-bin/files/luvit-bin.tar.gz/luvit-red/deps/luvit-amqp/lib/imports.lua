LJ $@bin/deps/luvit-amqp/lib/imports.lua�d   	 �6   ' B 9 ' B9 ' D qpid-proton	load�dint getsockopt(int s, int level, int optname, void *optval, int *optlen);
char *strerror(int errnum);

char *strndup(const char *s, size_t n);

int close(int fd);

typedef int32_t  pn_sequence_t;
typedef uint32_t pn_millis_t;
typedef uint32_t pn_seconds_t;
typedef int64_t  pn_timestamp_t;
typedef uint32_t pn_char_t;
typedef uint32_t pn_decimal32_t;
typedef uint64_t pn_decimal64_t;
typedef struct {
  char bytes[16];
} pn_decimal128_t;
typedef struct {
  char bytes[16];
} pn_uuid_t;

typedef struct {
  size_t size;
  const char *start;
} pn_bytes_t;

pn_bytes_t pn_bytes(size_t size, const char *start);

typedef enum {
  PN_NULL = 1,
  PN_BOOL = 2,
  PN_UBYTE = 3,
  PN_BYTE = 4,
  PN_USHORT = 5,
  PN_SHORT = 6,
  PN_UINT = 7,
  PN_INT = 8,
  PN_CHAR = 9,
  PN_ULONG = 10,
  PN_LONG = 11,
  PN_TIMESTAMP = 12,
  PN_FLOAT = 13,
  PN_DOUBLE = 14,
  PN_DECIMAL32 = 15,
  PN_DECIMAL64 = 16,
  PN_DECIMAL128 = 17,
  PN_UUID = 18,
  PN_BINARY = 19,
  PN_STRING = 20,
  PN_SYMBOL = 21,
  PN_DESCRIBED = 22,
  PN_ARRAY = 23,
  PN_LIST = 24,
  PN_MAP = 25
} pn_type_t;

const char *pn_type_name(pn_type_t type);

typedef struct {
  pn_type_t type;
  union {
    bool as_bool;
    uint8_t as_ubyte;
    int8_t as_byte;
    uint16_t as_ushort;
    int16_t as_short;
    uint32_t as_uint;
    int32_t as_int;
    pn_char_t as_char;
    uint64_t as_ulong;
    int64_t as_long;
    pn_timestamp_t as_timestamp;
    float as_float;
    double as_double;
    pn_decimal32_t as_decimal32;
    pn_decimal64_t as_decimal64;
    pn_decimal128_t as_decimal128;
    pn_uuid_t as_uuid;
    pn_bytes_t as_bytes;
  } u;
} pn_atom_t;

// data

typedef struct pn_data_t pn_data_t;

pn_data_t *pn_data(size_t capacity);
void pn_data_free(pn_data_t *data);
int pn_data_errno(pn_data_t *data);
int pn_data_vfill(pn_data_t *data, const char *fmt, va_list ap);
int pn_data_fill(pn_data_t *data, const char *fmt, ...);
int pn_data_vscan(pn_data_t *data, const char *fmt, va_list ap);
int pn_data_scan(pn_data_t *data, const char *fmt, ...);

void pn_data_clear(pn_data_t *data);
size_t pn_data_size(pn_data_t *data);
void pn_data_rewind(pn_data_t *data);
bool pn_data_next(pn_data_t *data);
bool pn_data_prev(pn_data_t *data);
bool pn_data_enter(pn_data_t *data);
bool pn_data_exit(pn_data_t *data);
bool pn_data_lookup(pn_data_t *data, const char *name);

pn_type_t pn_data_type(pn_data_t *data);

int pn_data_print(pn_data_t *data);
int pn_data_format(pn_data_t *data, char *bytes, size_t *size);

typedef int ssize_t;

ssize_t pn_data_encode(pn_data_t *data, char *bytes, size_t size);
ssize_t pn_data_decode(pn_data_t *data, const char *bytes, size_t size);

int pn_data_put_list(pn_data_t *data);
int pn_data_put_map(pn_data_t *data);
int pn_data_put_array(pn_data_t *data, bool described, pn_type_t type);
int pn_data_put_described(pn_data_t *data);
int pn_data_put_null(pn_data_t *data);
int pn_data_put_bool(pn_data_t *data, bool b);
int pn_data_put_ubyte(pn_data_t *data, uint8_t ub);
int pn_data_put_byte(pn_data_t *data, int8_t b);
int pn_data_put_ushort(pn_data_t *data, uint16_t us);
int pn_data_put_short(pn_data_t *data, int16_t s);
int pn_data_put_uint(pn_data_t *data, uint32_t ui);
int pn_data_put_int(pn_data_t *data, int32_t i);
int pn_data_put_char(pn_data_t *data, pn_char_t c);
int pn_data_put_ulong(pn_data_t *data, uint64_t ul);
int pn_data_put_long(pn_data_t *data, int64_t l);
int pn_data_put_timestamp(pn_data_t *data, pn_timestamp_t t);
int pn_data_put_float(pn_data_t *data, float f);
int pn_data_put_double(pn_data_t *data, double d);
int pn_data_put_decimal32(pn_data_t *data, pn_decimal32_t d);
int pn_data_put_decimal64(pn_data_t *data, pn_decimal64_t d);
int pn_data_put_decimal128(pn_data_t *data, pn_decimal128_t d);
int pn_data_put_uuid(pn_data_t *data, pn_uuid_t u);
int pn_data_put_binary(pn_data_t *data, pn_bytes_t bytes);
int pn_data_put_string(pn_data_t *data, pn_bytes_t string);
int pn_data_put_symbol(pn_data_t *data, pn_bytes_t symbol);
int pn_data_put_atom(pn_data_t *data, pn_atom_t atom);

size_t pn_data_get_list(pn_data_t *data);
size_t pn_data_get_map(pn_data_t *data);
size_t pn_data_get_array(pn_data_t *data);
bool pn_data_is_array_described(pn_data_t *data);
pn_type_t pn_data_get_array_type(pn_data_t *data);
bool pn_data_is_described(pn_data_t *data);
bool pn_data_is_null(pn_data_t *data);
bool pn_data_get_bool(pn_data_t *data);
uint8_t pn_data_get_ubyte(pn_data_t *data);
int8_t pn_data_get_byte(pn_data_t *data);
uint16_t pn_data_get_ushort(pn_data_t *data);
int16_t pn_data_get_short(pn_data_t *data);
uint32_t pn_data_get_uint(pn_data_t *data);
int32_t pn_data_get_int(pn_data_t *data);
pn_char_t pn_data_get_char(pn_data_t *data);
uint64_t pn_data_get_ulong(pn_data_t *data);
int64_t pn_data_get_long(pn_data_t *data);
pn_timestamp_t pn_data_get_timestamp(pn_data_t *data);
float pn_data_get_float(pn_data_t *data);
double pn_data_get_double(pn_data_t *data);
pn_decimal32_t pn_data_get_decimal32(pn_data_t *data);
pn_decimal64_t pn_data_get_decimal64(pn_data_t *data);
pn_decimal128_t pn_data_get_decimal128(pn_data_t *data);
pn_uuid_t pn_data_get_uuid(pn_data_t *data);
pn_bytes_t pn_data_get_binary(pn_data_t *data);
pn_bytes_t pn_data_get_string(pn_data_t *data);
pn_bytes_t pn_data_get_symbol(pn_data_t *data);
pn_bytes_t pn_data_get_bytes(pn_data_t *data);
pn_atom_t pn_data_get_atom(pn_data_t *data);

int pn_data_copy(pn_data_t *data, pn_data_t *src);
int pn_data_append(pn_data_t *data, pn_data_t *src);
int pn_data_appendn(pn_data_t *data, pn_data_t *src, int limit);
void pn_data_narrow(pn_data_t *data);
void pn_data_widen(pn_data_t *data);

void pn_data_dump(pn_data_t *data);

typedef struct pn_selectable_t pn_selectable_t;

typedef unsigned int pn_socket_t;

typedef void (*pn_logger_t)(const char *message);
void pn_log_enable(bool enabled);
void pn_log_logger(pn_logger_t logger);

pn_socket_t pn_selectable_get_fd(pn_selectable_t *selectable);
// ssize_t pn_selectable_capacity(pn_selectable_t *selectable);
// ssize_t pn_selectable_pending(pn_selectable_t *selectable);
bool pn_selectable_is_writing(pn_selectable_t *selectable);
bool pn_selectable_is_reading(pn_selectable_t *selectable);

pn_timestamp_t pn_selectable_get_deadline(pn_selectable_t *selectable);
void pn_selectable_readable(pn_selectable_t *selectable);
void pn_selectable_writable(pn_selectable_t *selectable);
void pn_selectable_expired(pn_selectable_t *selectable);
bool pn_selectable_is_registered(pn_selectable_t *selectable);
void pn_selectable_set_registered(pn_selectable_t *selectable, bool registered);
bool pn_selectable_is_terminal(pn_selectable_t *selectable);
void pn_selectable_free(pn_selectable_t *selectable);
void pn_selectable_on_error(pn_selectable_t *sel, void (*error)(pn_selectable_t *));
void pn_selectable_terminate(pn_selectable_t *selectable);

typedef enum {
  PN_STATUS_UNKNOWN = 0, /**< The tracker is unknown. */
  PN_STATUS_PENDING = 1, /**< The message is in flight. For outgoing
                            messages, use ::pn_messenger_buffered to
                            see if it has been sent or not. */
  PN_STATUS_ACCEPTED = 2, /**< The message was accepted. */
  PN_STATUS_REJECTED = 3, /**< The message was rejected. */
  PN_STATUS_RELEASED = 4, /**< The message was released. */
  PN_STATUS_MODIFIED = 5, /**< The message was modified. */
  PN_STATUS_ABORTED = 6, /**< The message was aborted. */
  PN_STATUS_SETTLED = 7 /**< The remote party has settled the message. */
} pn_status_t;

typedef struct 	pn_message_t pn_message_t;
pn_message_t * 	pn_message(void);
void           	pn_message_free(pn_message_t *msg);
void           	pn_message_clear(pn_message_t *msg);
int            	pn_message_errno(pn_message_t *msg);
int         	pn_message_set_address(pn_message_t *msg, const char *address);
const char *   	pn_message_get_address(pn_message_t *msg);
pn_millis_t    	pn_message_get_ttl(pn_message_t *msg);
int            	pn_message_set_ttl(pn_message_t *msg, pn_millis_t ttl);

pn_data_t *		pn_message_body(pn_message_t *msg);
// String keyed map
pn_data_t *		pn_message_properties(pn_message_t *msg);
// Next 2 need to be symbol keyed maps
pn_data_t *		pn_message_annotations(pn_message_t *msg);
pn_data_t *		pn_message_instructions(pn_message_t *msg);
const char *   	pn_message_get_content_type(pn_message_t *msg);
int            	pn_message_set_content_type(pn_message_t *msg, const char *type);
bool           pn_message_is_inferred(pn_message_t *msg);
int            pn_message_set_inferred(pn_message_t *msg, bool inferred);
const char *   pn_message_get_subject(pn_message_t *msg);
int            pn_message_set_subject(pn_message_t *msg, const char *subject);
const char *   pn_message_get_reply_to(pn_message_t *msg);
int            pn_message_set_reply_to(pn_message_t *msg, const char *reply_to);
pn_atom_t      pn_message_get_correlation_id(pn_message_t *msg);
int            pn_message_set_correlation_id(pn_message_t *msg, pn_atom_t id);
pn_timestamp_t pn_message_get_expiry_time(pn_message_t *msg);
int            pn_message_set_expiry_time(pn_message_t *msg, pn_timestamp_t time);
pn_timestamp_t pn_message_get_creation_time(pn_message_t *msg);
int            pn_message_set_creation_time(pn_message_t *msg, pn_timestamp_t time);
pn_data_t *    pn_message_id(pn_message_t *msg);
pn_atom_t      pn_message_get_id(pn_message_t *msg);
const char *   pn_message_get_group_id          (pn_message_t *msg);
int            pn_message_set_group_id          (pn_message_t *msg, const char *group_id);
const char *   pn_message_get_reply_to_group_id (pn_message_t *msg);
int            pn_message_set_reply_to_group_id (pn_message_t *msg, const char *reply_to_group_id);

typedef struct pn_terminus_t pn_terminus_t;
typedef struct pn_link_t pn_link_t;
typedef struct pn_transport_t pn_transport_t;
typedef struct pn_subscription_t pn_subscription_t;
typedef struct pn_messenger_t pn_messenger_t;
typedef int64_t pn_tracker_t;
typedef struct pn_error_t pn_error_t;
typedef void (*pn_tracer_t)(pn_transport_t *transport, const char *message);

const char* pn_error_text(pn_error_t * 	error);

pn_terminus_t *pn_link_source(pn_link_t *link);
pn_data_t *pn_terminus_filter(pn_terminus_t *terminus);

pn_messenger_t *pn_messenger(const char *name);
const char *pn_messenger_name(pn_messenger_t *messenger);
bool pn_messenger_is_blocking(pn_messenger_t *messenger);
int pn_messenger_set_blocking(pn_messenger_t *messenger, bool blocking);
bool pn_messenger_is_passive(pn_messenger_t *messenger);
int pn_messenger_set_passive(pn_messenger_t *messenger, bool passive);
int pn_messenger_incoming(pn_messenger_t *messenger);
int pn_messenger_outgoing(pn_messenger_t *messenger);
void pn_messenger_free(pn_messenger_t *messenger);
int pn_messenger_errno(pn_messenger_t *messenger);
pn_error_t* pn_messenger_error(	pn_messenger_t *messenger);
int pn_messenger_start(pn_messenger_t *messenger);
int pn_messenger_stop(pn_messenger_t *messenger);
bool pn_messenger_stopped(pn_messenger_t *messenger);
int pn_messenger_put(pn_messenger_t *messenger, pn_message_t *msg);
int pn_messenger_get(pn_messenger_t *messenger, pn_message_t *message);
int pn_messenger_send(pn_messenger_t *messenger, int n);
int pn_messenger_recv(pn_messenger_t *messenger, int limit);
pn_selectable_t *pn_messenger_selectable(pn_messenger_t *messenger);
pn_subscription_t* pn_messenger_subscribe(pn_messenger_t *messenger,const char *source);
pn_subscription_t* pn_messenger_subscribe_ttl(pn_messenger_t *messenger, const char *source,
                           pn_seconds_t timeout);
pn_subscription_t* pn_messenger_incoming_subscription(pn_messenger_t *messenger);
int pn_messenger_work(pn_messenger_t *messenger, int timeout);
pn_tracker_t pn_messenger_incoming_tracker(pn_messenger_t *messenger);
int pn_messenger_accept(pn_messenger_t *messenger, pn_tracker_t tracker, int flags);
int pn_messenger_reject(pn_messenger_t *messenger, pn_tracker_t tracker, int flags);
int pn_messenger_set_outgoing_window(pn_messenger_t *messenger, int window);
int pn_messenger_set_incoming_window(pn_messenger_t *messenger, int window);
pn_tracker_t pn_messenger_outgoing_tracker(pn_messenger_t *messenger);
pn_status_t pn_messenger_status(pn_messenger_t *messenger, pn_tracker_t tracker);
void pn_messenger_set_tracer(pn_messenger_t *messenger, pn_tracer_t tracer);
pn_link_t *pn_messenger_get_link(pn_messenger_t *messenger, const char *address, bool sender);

typedef enum pn_snd_settle_mode_t { PN_SND_UNSETTLED = 0, PN_SND_SETTLED = 1, PN_SND_MIXED = 2 } pn_snd_settle_mode_t;
typedef enum pn_rcv_settle_mode_t { PN_RCV_FIRST = 0, PN_RCV_SECOND = 1 } pn_rcv_settle_mode_t;
int pn_messenger_set_snd_settle_mode(pn_messenger_t *messenger, const pn_snd_settle_mode_t mode);
int pn_messenger_set_rcv_settle_mode(pn_messenger_t *messenger, const pn_rcv_settle_mode_t mode);
	cdefffirequire    CCEEEffi   