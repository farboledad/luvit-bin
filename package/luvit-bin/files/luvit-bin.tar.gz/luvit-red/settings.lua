--  Copyright 2014 Option NV
--
--  Licensed under the Apache License, Version 2.0 (the "License");
--  you may not use this file except in compliance with the License.
--  You may obtain a copy of the License at
--
--  http://www.apache.org/licenses/LICENSE-2.0
--
--  Unless required by applicable law or agreed to in writing, software
--  distributed under the License is distributed on an "AS IS" BASIS,
--  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--  See the License for the specific language governing permissions and
--  limitations under the License.

-- CloudGate settings file

return {
    uiPort=8080,
    storageModule="ucistore",
    firewallProvider="cgfirewall",
    activityTimeout=true,
    queueDBDirectory="/etc/luvitred",
    litServer = {
        url = "http://81.246.70.170:4822",
        ws = "ws://81.246.70.170:4822",
        flowsTag = "luvitredflow",
        nodesTag = "luvitrednode",
        nodesDir="/etc/luvitred/installed_nodes",
        dbDir="/etc/luvitred/litdb"
    },
    userDir="/etc/luvitred/store",
    tls={
        cafile="/rom/mnt/cust/luvit-red/cacert.pem"
    },
    nodesDirs={
        {
            dir="./nodes",
            readOnly=true
        },
        {
            dir="/etc/luvitred/installed_nodes",
            readOnly=false
        },
    },
    https={
        port=8081,
        keyfile="/etc/certs/lighttpd.pem" -- contains key and cert
    },
    nodeAliases={
        ["m2x key"]="M2X key",
        ["m2x out"]="M2X out",
        ["modbus serial port"]="modbus requester",
        ["zigbee discovery"]="zigbee monitor",
        ["cg-led"]="cg led"
    },
    mqttReconnectTime=15000,
    serialReconnectTime=15000,
    debugMaxLength=1000,
    functionGlobalContext={
    }
}
