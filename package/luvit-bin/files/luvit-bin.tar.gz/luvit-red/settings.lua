-- Copyright (C) 2014 Option NV - All Rights Reserved
-- Unauthorized copying of this file, via any medium is strictly prohibited
-- Proprietary and confidential

-- LuvitRED CloudGate settings file

return {
    uiPort=8080,
    storageModule="ucistore",
    firewallProvider="cgfirewall",
    activityTimeout=true,
    queueDBDirectory="/etc/luvitred",
    litServer = {
        url = "http://81.246.70.170:4822",
        ws = "ws://81.246.70.170:4822",
        flowsTag = "luvitredflow",
        nodesTag = "luvitrednode",
        nodesDir="/etc/luvitred/installed_nodes",
        dbDir="/etc/luvitred/litdb"
    },
    userDir="/etc/luvitred/store",
    tls={
        cafile="/rom/mnt/cust/luvit-red/cacert.pem"
    },
    nodesDirs={
        {
            dir="./nodes",
            readOnly=true
        },
        {
            dir="/etc/luvitred/installed_nodes",
            readOnly=false
        },
    },
    https={
        port=8081,
        keyfile="/etc/certs/lighttpd.pem", -- contains key and cert
    },
    nodeAliases={
        ["m2x key"]="M2X key",
        ["m2x out"]="M2X out",
        ["modbus serial port"]="modbus requester",
        ["zigbee discovery"]="zigbee monitor",
        ["cg-led"]="cg led"
    },
    functionGlobalContext={
    }
}
