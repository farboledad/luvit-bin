
(function() {
	'use strict';
	plugInModule.controller('uiComponentCtrl', ['$scope',
		function ($scope) {
			$scope.url = $scope.$parent.$parent.url;
		}
	]);
})();