
(function() {
	'use strict';
	plugInModule.controller('uiCtrl', ['$scope', '$http',
		function ($scope, $http) {

			var title = encodeURIComponent($scope.$parent.title);
			$scope.url = 'api/libcg/ui_sections' + title;

			$http.get($scope.url, {timeout: 5000})
				.then(function(result) {
					var j = result.data;
					var sections = [];
					for(var i=0;i<result.data;i++) {
						$http.get($scope.url, {timeout: 5000, params: {section: i}})
							.then(function(result) {
								sections[result.config.params.section] = result.data;
								j--;
								if (j===0) {
									$scope.sections = sections;
								}
							}, function(result) {
								j--;
								sections[result.config.params.section] = {
									order: 1,
									header: 'Error',
									items: [
										{
											order: 1,
											type: 'text',
											text: 'Failed to load section'
										},
									]
								}
								if (j===0) {
									$scope.sections = sections;
								}
							}
						);
					}
				}, function(result) {
					$scope.sections = [
						{
							order: 1,
							header: 'Error',
							items: [
								{
									order: 1,
									type: 'text',
									text: 'Failed to load sections from LuvitRED'
								},
							]
						}
					];
					$scope.sectionsOld = $scope.sections;
				});
		}
	]);
})();