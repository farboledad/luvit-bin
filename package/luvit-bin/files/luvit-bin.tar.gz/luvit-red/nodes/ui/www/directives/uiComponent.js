
(function() {
	'use strict';
	plugInModule.directive('uiComponent', [
		function () {
			return {
				restrict: 'E',
				controller: 'uiComponentCtrl',
				template: '<ng-include src="template" />',
				replace:true,
				scope: {
					item: '='
				},
				link: function postLink(scope) {
					scope.template = 'ui/templates/' + scope.item.type + '.html';
				}
			};
		}
	]);
})();