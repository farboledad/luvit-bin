(function() {
  'use strict';
  plugInModule.controller("uiChartCtrl", ["$scope", "$timeout", "$http",
    function ($scope, $timeout, $http) {
      var basis = [];
      var tout;
      var destroyed;
      var last_from = 0;
      var last_to = 0;
      var scale = 1;
      var dst_series = [];

      $scope.xlabel = 'Time';
      $scope.enable_controls = false;
      $scope.update_enabled = false;

      var isNumber = function(obj) { return !isNaN(parseFloat(obj)) };

      var setScale = function(from, to) {
        last_from = from;
        last_to = to;
        var range = to - from;
        var conv;
        var unit;
        if (range < 2*60) {
          unit = 'secs';
          conv = 1;
        } else if (range < 2*60*60) {
          unit = 'mins';
          conv = 60;
        } else if (range < 2*24*60*60) {
          unit = 'hours';
          conv = 3600;
        } else {
          unit = 'days';
          conv = 86400;
        }
        $scope.xlabel = 'Time (' + unit + ')';
        return conv;
      };

      var plotData = function(data_srces) {
        var no_points = true;
        var limit = $scope.item.limit||10;
        // drop the datapoints we do not need
        for(var i=0;i<data_srces.length;i++) {
          var data_src = data_srces[i];
          if (!data_src||data_src.length<=0) continue;
          no_points = false;
          var series_dst = dst_series[i];
          var data_dst = series_dst.data;
          var len = data_src.length + data_dst.length;
          while (len>series_dst.size) {
            if (data_dst.length > 0) {
              data_dst.shift();
            } else {
              data_src.shift();
            }
            len = len - 1;
          }
        }

        if (no_points) return;

        var from = Number.MAX_VALUE;
        var to = 0;

        // calculate the new from and to
        for(var i=0;i<data_srces.length;i++) {
          var data_src = data_srces[i];
          var data_dest = dst_series[i].data;
          if (data_src.length > 0) {
            if (data_src[data_src.length - 1].x>to) to = data_src[data_src.length - 1].x;
            if (data_src[0].x<from) from = data_src[0].x;
          }
          if (data_dest.length > 0) {
            if (data_dest[data_dest.length - 1].o>to) to = data_dest[data_dest.length - 1].o;
            if (data_dest[0].o<from) from = data_dest[0].o;
          }
        }

        scale = setScale(from, to);
        // use the full width
        $scope.item.options.axisX.low = (from - last_to)/scale;
        // re scale all points
        for(var i=0;i<data_srces.length;i++) {
          var data_dst = dst_series[i].data;
          var data_src = data_srces[i];

          for (var j=0;j<data_dst.length;j++) {
            data_dst[j].x = (data_dst[j].o - last_to)/scale;
          }

          for (var j=0;j<data_src.length;j++) {
            data_src[j].o = data_src[j].x;
            data_src[j].x = (data_src[j].o - last_to)/scale;
            data_dst.push(data_src[j]);
          }
        }
      };

      var getData = function() {
        tout = null;
        $http.get($scope.item.url, {timeout: 5000, params: {last: last_to}})
        .then(function(result) {
          if (destroyed||!$scope.update_enabled) return;
          plotData(result.data);
          $scope.enableUpdate(true, true);
        },
        function(err){
          if (destroyed||!$scope.update_enabled) return;
          $scope.enableUpdate(true, true);
        });
      };

      $scope.$on('$destroy', function() {
        if (tout) {
          $timeout.cancel(tout);
          tout = null;
          destroyed = true;
        }
      });

      // first calculate from and to values
      // take a reference to each element in the series table in a private array since the
      // legend plugin moves them in and out of the actual series array
      var initial_series = [];
      for(var i=0;i<$scope.item.data.series.length;i++) {
        if ($scope.item.data.series[i]) {
          dst_series[i] = $scope.item.data.series[i];
          initial_series[i] = $scope.item.data.series[i].data;
          $scope.item.data.series[i].data = [];
        } else {
          dst_series[i] = { data:[] };
          initial_series[i] = [];
          $scope.item.data.series[i] = dst_series[i];
        }
      }

      $scope.enableUpdate = function(enable, delayed) {
        if (!$scope.item.url) return;
        if (enable&&isNumber($scope.item.interval)) {
          tout=$timeout(getData, (delayed?$scope.item.interval*1000:0));
          $scope.update_enabled = true;
        } else {
          if (tout) {
            $timeout.cancel(tout);
          }
          $scope.update_enabled = false;
        }
      };

      if ($scope.item.url) {
        $scope.enable_controls = true;
        $scope.enableUpdate(true, true);
      }

      $scope.item.options = {
        axisX: {
          type:Chartist.AutoScaleAxis,
          onlyInteger: true,
          scaleMinSpace: 50,
        },
        lineSmooth: Chartist.Interpolation.monotoneCubic({
          fillHoles: true,
        }),
        plugins: [
          Chartist.plugins.ctAxisTitle({
            axisX: {
              axisTitle: function() { return $scope.xlabel },
              axisClass: 'ct-axis-title',
              offset: {x:0, y:30},
              textAnchor: 'middle'
            },
            axisY: {
              axisTitle: $scope.item.ylabel,
              axisClass: 'ct-axis-title',
              textAnchor: 'middle',
              offset: {x:0, y:10},
              flipTitle: true
            }
          }),
          Chartist.plugins.tooltip({
            tooltipFnc: function(meta, value) {
              value = value.split(',');
              var time = value.length > 1 ? parseFloat(value[0]) : 0;
              value = parseFloat(value[value.length -1] || 0);
              var date = new Date((time*scale+last_to)*1000);
              return meta + '<br>' + date.toLocaleDateString() + '<br>' + date.toLocaleTimeString() + '<br>' + value;
            }
          }),
          Chartist.plugins.legend()
        ]
      };

      // start work
      plotData(initial_series);
      initial_series = null;
    }
  ]);
})();
