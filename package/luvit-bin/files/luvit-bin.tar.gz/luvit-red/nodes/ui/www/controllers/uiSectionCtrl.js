
(function() {
	'use strict';
	plugInModule.controller('uiSectionCtrl', ['$scope', '$http',
		function ($scope, $http) {
			$scope.url = $scope.$parent.$parent.$parent.url;
			$scope.sectionOld = angular.copy($scope.section);

			$scope.save = function() {
				var data = {
					items: $scope.section.items,
					type: 'save'
				};
				$http.post($scope.url, data)
					.then(function(result) {
						var sections = $scope.$parent.$parent.$parent.sections;
						for (var i = sections.length - 1; i >= 0; i--) {
							var section = sections[i];
							for (var j = section.items.length - 1; j >= 0; j--) {
								sections[i].items[j] = result.data[i].items[j];
							}
						}
						$scope.sectionOld = angular.copy($scope.section);
					}
				);
			};

			$scope.cancel = function() {
				// TODO: avoid item duplication on screen
				//$scope.section = angular.copy($scope.sectionOld);
				//window.location.reload();
			};

			$scope.disabled = function() {
				for (var i = $scope.section.items.length - 1; i >= 0; i--) {
					var item = $scope.section.items[i];
					if (item.required && item.value == null) {
						return true;
					}
				}
				return angular.equals($scope.section, $scope.sectionOld);
			};

			$scope.showSubmit = function() {
				for (var i = $scope.section.items.length - 1; i >= 0; i--) {
					var type = $scope.section.items[i].type;
					if (type == 'button' || type == 'text' || type == 'chartist-line') {
						continue;
					}
					return true;
				}
				return false;
			};
		}
	]);
})();