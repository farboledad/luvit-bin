
(function() {
	'use strict';
	plugInModule.controller('uiSelectCtrl', ['$scope', '$http',
		function ($scope) {
			// workaround for 1.0.7 deep compare to show default value
			if ($scope.item.hasOwnProperty('value')) {
				for (var i = 0; i < $scope.item.options.length; i++) {
					if ($scope.item.options[i].label == $scope.item.value.label) {
						if ($scope.item.options[i].payload == $scope.item.value.payload) {
							$scope.item.value = $scope.item.options[i];
							break;
						}
					}
				}
			}
		}
	]);
})();