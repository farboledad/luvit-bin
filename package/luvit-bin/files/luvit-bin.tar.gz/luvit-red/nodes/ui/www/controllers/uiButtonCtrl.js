
(function() {
	'use strict';
	plugInModule.controller('uiButtonCtrl', ['$scope', '$http',
		function ($scope, $http) {
			$scope.buttonClick = function() {
				var data = {
					items: [ $scope.item ],
					type: 'buttonClick'
				};
				$http.post($scope.url, data)
					.then(function(result) {
						var sections = $scope.$parent.$parent.$parent.$parent.$parent.$parent.$parent.sections;
						for (var i = sections.length - 1; i >= 0; i--) {
							var section = sections[i];
							for (var j = section.items.length - 1; j >= 0; j--) {
								sections[i].items[j] = result.data[i].items[j];
							}
						}
					});
			};
		}
	]);
})();