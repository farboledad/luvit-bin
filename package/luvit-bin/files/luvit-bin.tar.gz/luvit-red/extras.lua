-- Copyright (C) 2014 Option NV - All Rights Reserved
-- Unauthorized copying of this file, via any medium is strictly prohibited
-- Proprietary and confidential

local cg = require("cglib")
local http = require('http')
local CgWWWAuth = require("cg-utopia-auth").CgWWWAuth
local JSON = require('json')
local UCI = require("uci2")(require('on_cloudgate')())
local _u = require('underscore')
local digest = require('openssl').digest
local log
local extras = {}
local CG_MENU_NAME = "LuvitRED"

extras.wwwauth = CgWWWAuth:new()

local function extractScenarios(flows)
	local scenariosFound, tabs, configNodes, nodesById = {}, {}, {}, {}
	_u.each(flows, function(node)
		if not node.id then return end
		nodesById[node.id] = node
		if node.type == "tab" then
			if not tabs[node.id] then
				tabs[node.id] = {}
			end
		elseif node.z then
			if node.type == "scenario" and not scenariosFound[node.name] then
				scenariosFound[node.name] = node.z
			end
			if not tabs[node.z] then
				tabs[node.z] = { node }
			else
				table.insert(tabs[node.z], node)
			end
		else
			configNodes[node.id] = node
		end
	end)
	local resultNodes = {}
	_u.each(_u.keys(scenariosFound), function(name)
		local flow = tabs[scenariosFound[name]]
		resultNodes[scenariosFound[name]] = nodesById[scenariosFound[name]]
		_u.each(flow, function(node)
			resultNodes[node.id] = node
			for propertyName, propertyValue in pairs(node) do
				if propertyName ~= "id" and type(propertyValue) == "string" then
					local id = propertyValue:match("^([a-z0-9]+%.[a-z0-9]+)$")
					if id and not resultNodes[id] and configNodes[id] then
						resultNodes[id] = configNodes[id]
					end
				end
			end
		end)
	end)
	-- important to preserve order of original nodes
	local inScenario, outScenario = {}, {}
	_u.each(flows, function(node)
		if resultNodes[node.id] then
			table.insert(inScenario, node)
		else
			table.insert(outScenario, node)
		end
	end)
	return inScenario, outScenario
end

local function preinit(framework, settings, logger)
	log = logger:getLogFunctions("extras")

	extras.wwwauth:on("error", function(msg) log.errorf("%s", msg) end)
	extras.wwwauth:on("log", function(msg) log.logf("%s", msg) end)
	if settings.activityTimeout ~= false then
		framework:use(extras.wwwauth:request())
	end
end
extras.preinit = preinit

-- local function postinit(RED)
-- end
-- extras.postinit = postinit

local cgcallbacks = {}
local function start(RED, done)

	local childProcess = require('childprocess')
	local snmpProcess = nil

	local function startSNMP()
		if not snmpProcess then
			snmpProcess = childProcess.spawn('/rom/mnt/cust/bin/snmpconfig', {}, {
				stdio = {nil, nil, nil}
			})

			snmpProcess:once('close', function()
				snmpProcess = nil
			end)
		end
	end

	local function stopSNMP()
		if snmpProcess then
			snmpProcess:kill('sigusr1')
		end
	end

	local uci = UCI:new()
	local function flowLocked()
		local flowLockNodes = RED.nodes.getNodesByType("flow lock")
		if not flowLockNodes then
			return false
		end
		local anode = _u.detect(flowLockNodes, function(node)
			return node.__nstat == "active"
		end)
		return anode and #anode.password ~= 0
	end

	local function redHidden()
		local flowLockNodes = RED.nodes.getNodesByType("flow lock")
		if not flowLockNodes then
			return false
		end
		local anode = _u.detect(flowLockNodes, function(node)
			return node.__nstat == "active"
		end)
		return anode and anode.hidered
	end

	local function snmpHidden()
		local flowLockNodes = RED.nodes.getNodesByType("flow lock")
		if not flowLockNodes then
			return false
		end
		local anode = _u.detect(flowLockNodes, function(node)
			return node.__nstat == "active"
		end)
		return anode and anode.hidesnmp
	end

	local function checkPassword(password)
		if not password then
			return false
		end
		local flowLockNodes = RED.nodes.getNodesByType("flow lock")
		if flowLockNodes then
			local anode = _u.detect(flowLockNodes, function(node)
				return node.__nstat == "active"
			end)
			if anode then
				local pwstring = anode.password
				if pwstring and string.sub(pwstring, 1,2) == "$5" then -- SHA-256 encoded password
					local salt = string.sub(pwstring, 4,11)
					local hash = string.sub(pwstring, 13)
					local sha256 = digest.get("sha256")
					local d = digest.new(sha256)
					d:update(password)
					d:update(salt)
					local ret = d:final()
					if ret == hash then
						return true
					end
				end
			end
		end
		return false
	end

	local option = uci:getOption("firewall", "https_settings", "port")
	local cghttpsport = option and tonumber(option:getValue())
	if cghttpsport then
		if RED.firewall and type(RED.settings.https) == "table" and type(RED.settings.https.port) == "number" then
			log.logf("remote access enabled - opening firewall hole for luvitred on port %s", RED.settings.https.port)
			RED.firewall.registerHole("tcp", RED.settings.https.port)
		else
			log.warn("invalid settings.https.port or no firewall - not registering port forward")
		end
	else
		log.warn("no CG UI https port setting. perhaps remote access is disabled")
		cghttpsport = nil
	end

	extras.editorEnabled = false

	RED.comms.subscribe(function(_, message)
		if message.session then
			local content = string.format('{"session":"%s"}', message.session)
			local req = http.request({
				host="127.0.0.1",
				port=80,
				path="/api/libcg/editorEnabled",
				method="POST",
				headers={
					["Cookie"] = string.format("session=%s", message.session),
					["Content-Type"] = "application/json",
					["Content-Length"] = #content,
					["Connection"] = "close"
				}
			})
			req:write(content)
			req:done()
		end
	end, "activity")

	local function registerCallback(name, err, msg)
		if err then
			log.errorf("error registering %s callback - %s", name, msg)
		else
			table.insert(cgcallbacks, msg)
		end
	end

	registerCallback("cgui get flows", cg.ui.registerGetCallback("flows", function(_, loggedin, result)
		if loggedin then
			local flows = extractScenarios(RED.nodes.getFlows())
			return result(JSON.stringify(flows))
		end
		return result(nil)
	end))

	registerCallback("cgui post flows", cg.ui.registerJsonCallback("flows", function(sflows, loggedin, result)
		if loggedin then
			local ok1, flows = pcall(JSON.parse, sflows)
			if ok1 and flows then
				local _, nonScenario = extractScenarios(RED.nodes.getFlows())
				_u.each(nonScenario, function(node)
					table.insert(flows, node)
				end)
				return RED.nodes.setFlows(flows):and_then(function()
					return result("{}")
				end):catch(function(err1)
					log.errorf("error setting red nodes flows - %s", err1)
					return result(nil)
				end)
			end
			return result(nil)
		end
		return result(nil)
	end))

	registerCallback("cgui editorEnabled", cg.ui.registerJsonCallback("editorEnabled", function(sdata, loggedin, result)
		if not loggedin or not sdata then
			return result(nil)
		end
		local ok, data = pcall(JSON.parse, sdata)
		if not ok or not data or not data.session then
			return result(nil)
		end
		local session = tonumber(data.session, 16)

		local unlocked = true
		if flowLocked() and (not session or not extras.wwwauth:isAuthorized(session)) then
			unlocked = false
		end

		return result(JSON.stringify({
			httpport = RED.settings.uiPort,
			httpsport = RED.settings.https and RED.settings.https.port or nil,
			enabled = unlocked
		}))
	end))

	registerCallback("cgui enableEditor", cg.ui.registerJsonCallback("enableEditor", function(sdata, loggedin, result)
		if not loggedin then
			return result(nil)
		end
		if not sdata then
			return result('{"enabled":false}')
		end
		local ok, data = pcall(JSON.parse, sdata)
		if not ok then
			log.errorf("enableEditor - parse error for enable editor callback - %s", data)
			return result('{"enabled":false}')
		end
		if not checkPassword(data.password) then
			log.error("enableEditor - invalid flow password entered")
			return result('{"enabled":false}')
		end
		local session = tonumber(data.session, 16)
		if not extras.wwwauth:authorize(session) then
			log.errorf("enableEditor - invalid session id - %s", session)
			return result('{"enabled":false}')
		end
		log.logf("enableEditor - flow unlocked for session - %s", session)
		return result('{"enabled":true}')
	end))

	RED.events:on("flowlock-session", function(enable)
		extras.wwwauth:authorizeAll(enable)
	end)

	RED.events:on("flowlock-password", function(password)
		extras.wwwauth:setProtected(#password ~= 0)
	end)

	RED.events:on("flowlock-hidepage", function(page, hide)
		if not page then return end
		if page:lower() == "luvitred" then
			if hide then
				cg.ui.deregisterPage(CG_MENU_NAME)
			else
				local err, msg = cg.ui.registerPage(CG_MENU_NAME, "luvitred/sfform.html")
				if err then
					log.errorf("error registering standard scenario page - %s", msg)
				end
			end
		elseif page:lower() == "snmp" then
			if hide then
				stopSNMP()
			else
				startSNMP()
			end
		end
	end)

	extras.wwwauth:on('removed-session', function(id)
		log.logf("cgui session %s removed", id)
		RED.comms.publish('session', {session=string.format("%x", id)}, false)
	end)

	extras.wwwauth:setProtected(flowLocked())

	local err, msg = extras.wwwauth:start(
		RED.settings.uiPort,
		(RED.settings.https and RED.settings.https.port or nil),
		cghttpsport,
		false
	)
	if err then
		log.errorf("error registering cgui callback - %s", msg)
	else
		extras.editorEnabled = true
	end

	if not redHidden() then
		err, msg = cg.ui.registerPage(CG_MENU_NAME, "luvitred/sfform.html")
		if err then
			log.errorf("error registering standard scenario page - %s", msg)
		end
	end

	if not snmpHidden() then
		startSNMP()
	end

	return done()
end
extras.start = start

local function stop()
	extras.wwwauth:stop()
	_u.each(cgcallbacks, cg.ui.deregisterCallback)
	cg.ui.deregisterPage(CG_MENU_NAME)
end
extras.stop = stop

return extras
