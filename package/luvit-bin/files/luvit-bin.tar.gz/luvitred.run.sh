#!/bin/sh

while true; do
	[ -z "`pidof luvi`" ] && ( cd /rom/mnt/cust/luvit-red ; /rom/mnt/cust/bin/luvi . -- -v 2>&1 | logger -t "luvitred" ; ) &
	sleep 20
done
