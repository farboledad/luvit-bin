#!/bin/sh
# isv initialize script for luvitred - no debugging

# disable core files. Safety if device previously had a debug build.
rm /.init_enable_core &> /dev/null

uci show luvitred > /dev/null 2>&1 || {
	echo "Setting default luvitred config"
	cp /rom/mnt/cust/luvit-red/luvitred.config /etc/config/luvitred
}

#check the CG universe luvitred version and load new app if needed
#f1 is CG universe luvitred app
f1=/rom/mnt/base_cfg/config/luvitred
#f2 holds md5 of CG universe luvitred app
f2=/etc/luvitred/store/luvitred_md5
#f3 is current luvitred app
f3=/etc/config/luvitred

if [ -e $f1 ]; then
  md5new=$(md5sum "$f1" | head -c32)
  if [ -e $f2 ]; then
    read md5old < $f2
    if [ $md5new = $md5old ]; then
      echo "no new CG universe luvitred app detected, keep current luvitred app"
    else
      echo "remove current luvitred app, use CG universe luvitred app"
      rm -f $f3
      echo $md5new > $f2
    fi
  else
    echo "remove current luvitred app, use CG universe luvitred app"
    rm -f $f3
    echo $md5new > $f2
  fi
else
  echo "no CG universe luvitred app, use current luvitred app"
  rm -f $f2
fi

touch /etc/config/cg_conf_snmpd

[ ! -f /etc/init.d/snmpd ] && {
  ln -s /rom/mnt/cust/etc/init.d/snmpd /etc/init.d/snmpd
}
