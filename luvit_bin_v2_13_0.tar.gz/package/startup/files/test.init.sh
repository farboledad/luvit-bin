#!/bin/sh
echo "init run $$"
