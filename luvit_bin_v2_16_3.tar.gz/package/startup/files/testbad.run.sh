#!/bin/sh
echo "bad starting $$"
